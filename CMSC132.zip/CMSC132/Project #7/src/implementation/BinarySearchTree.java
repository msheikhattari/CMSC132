package implementation;

import java.util.*;

public class BinarySearchTree<K, V> {
	/*
	 * You may not modify the Node class and may not add any instance nor static
	 * variables to the BinarySearchTree class.
	 */
	private class Node {
		private K key;
		private V value;
		private Node left, right;

		private Node(K key, V value) {
			this.key = key;
			this.value = value;
		}
	}

	private Node root;
	private int treeSize, maxEntries;
	private Comparator<K> comparator;

	public BinarySearchTree(Comparator<K> comparator, int maxEntries) {
		if (comparator == null || maxEntries < 1) {
			throw new IllegalArgumentException("STOP");
		}

		this.comparator = comparator;
		this.maxEntries = maxEntries;
		treeSize = 0;
		root = null;
	}

	public BinarySearchTree<K, V> add(K key, V value) throws TreeIsFullException {
		if (isFull()) {
			throw new TreeIsFullException("STOP");
		}

		if (key == null || value == null) {
			throw new IllegalArgumentException("STOP");
		}

		if (root == null) {
			root = new Node(key, value);
			treeSize++;
			return this;
		} else {
			return addAux(key, value, root);
		}
	}

	private BinarySearchTree<K, V> addAux(K key, V value, Node rootAux) throws TreeIsFullException {

		int comparison = comparator.compare(key, rootAux.key);

		if (isFull()) {
			throw new TreeIsFullException("STOP");
		}

		if (key == null || value == null || rootAux == null) {
			throw new IllegalArgumentException("STOP");
		}

		if (comparison == 0) {
			rootAux.value = value;
			return this;
		} else if (comparison < 0) {
			if (rootAux.left == null) {
				rootAux.left = new Node(key, value);
				treeSize++;
				return this;
			} else {
				return addAux(key, value, rootAux.left);
			}
		} else {
			if (rootAux.right == null) {
				rootAux.right = new Node(key, value);
				treeSize++;
				return this;
			} else {
				return addAux(key, value, rootAux.right);
			}
		}
	}

	public String toString() {
		if (root == null) {
			return "EMPTY TREE";
		} else {
			return toStringAux(root);
		}

	}

	private String toStringAux(Node rootAux) {
		return rootAux == null ? ""
				: toStringAux(rootAux.left) + "{" + rootAux.key + ":" + rootAux.value + "}"
						+ toStringAux(rootAux.right);
	}

	public boolean isEmpty() {
		return root == null;
	}

	public int size() {
		return treeSize;
	}

	public boolean isFull() {
		return treeSize == maxEntries;
	}

	public KeyValuePair<K, V> getMinimumKeyValue() throws TreeIsEmptyException {
		if (size() == 0) {
			throw new TreeIsEmptyException("STOP");
		}
		return getMinimumKeyValueAux(root);
	}

	private KeyValuePair<K, V> getMinimumKeyValueAux(Node rootAux) throws TreeIsEmptyException {
		if (size() == 0) {
			throw new TreeIsEmptyException("STOP");
		}

		if (rootAux.left == null) {
			return new KeyValuePair<K, V>(rootAux.key, rootAux.value);
		} else {
			return getMinimumKeyValueAux(rootAux.left);
		}
	}

	public KeyValuePair<K, V> getMaximumKeyValue() throws TreeIsEmptyException {
		if (size() == 0) {
			throw new TreeIsEmptyException("STOP");
		}
		return getMaximumKeyValueAux(root);
	}

	private KeyValuePair<K, V> getMaximumKeyValueAux(Node rootAux) throws TreeIsEmptyException {
		if (size() == 0) {
			throw new TreeIsEmptyException("STOP");
		}

		if (rootAux.right == null) {
			return new KeyValuePair<K, V>(rootAux.key, rootAux.value);
		} else {
			return getMaximumKeyValueAux(rootAux.right);
		}

	}

	public KeyValuePair<K, V> find(K key) {
		if (size() == 0) {
			return null;
		}

		return find(key, root);
	}

	private KeyValuePair<K, V> find(K key, Node rootAux) {
		if (rootAux == null) {
			return null;
		} else {
			int comparison = comparator.compare(key, rootAux.key);
			if (comparison == 0) {
				return new KeyValuePair<K, V>(rootAux.key, rootAux.value);
			} else if (comparison < 0) {
				return find(key, rootAux.left);
			} else {
				return find(key, rootAux.right);
			}
		}

	}

	public BinarySearchTree<K, V> delete(K key) throws TreeIsEmptyException {
		if (size() == 0) {
			throw new TreeIsEmptyException("STOP");
		}
		if (key == null) {
			throw new IllegalArgumentException("STOP");
		}

		return deleteAux(key, root, root);
	}

	private BinarySearchTree<K, V> deleteAux(K key, Node rootAux, Node parentRootAux) throws TreeIsEmptyException {
		if (rootAux == null) {
			return this;
		}

		int comparison = comparator.compare(key, rootAux.key);
		if (comparison == 0) {
			if (rootAux.left == null && rootAux.right == null) {
				if (parentRootAux.left == rootAux) {
					parentRootAux.left = null;
				} else if (parentRootAux.right == rootAux) {
					parentRootAux.right = null;
				} else {
					this.root = null;
					parentRootAux = null;
				}

				rootAux = null;

				treeSize--;
				return this;
			} else if (rootAux.left == null && rootAux.right != null) {
				KeyValuePair<K, V> pair = getMinimumKeyValueAux(rootAux.right);
				Node newNode = new Node(pair.getKey(), pair.getValue());
				newNode.right = rootAux.right;

				if (parentRootAux.left == rootAux) {
					parentRootAux.left = newNode;
				} else if (parentRootAux.right == rootAux) {
					parentRootAux.right = newNode;
				} else {
					this.root = newNode;
					parentRootAux = newNode;
				}

				rootAux = newNode;

				if (parentRootAux == rootAux) {
					return deleteAux(pair.getKey(), rootAux.right, parentRootAux);
				} else {
					if (parentRootAux.left == rootAux) {
						return deleteAux(pair.getKey(), rootAux.right, parentRootAux.left);
					} else {
						return deleteAux(pair.getKey(), rootAux.right, parentRootAux.right);
					}
				}

			} else if (rootAux.left != null && rootAux.right == null) {
				KeyValuePair<K, V> pair = getMaximumKeyValueAux(rootAux.left);
				Node newNode = new Node(pair.getKey(), pair.getValue());
				newNode.left = rootAux.left;

				if (parentRootAux.left == rootAux) {
					parentRootAux.left = newNode;
				} else if (parentRootAux.right == rootAux) {
					parentRootAux.right = newNode;
				} else {
					this.root = newNode;
					parentRootAux = newNode;
				}

				rootAux = newNode;

				if (parentRootAux == rootAux) {
					return deleteAux(pair.getKey(), rootAux.left, parentRootAux);
				} else {
					if (parentRootAux.left == rootAux) {
						return deleteAux(pair.getKey(), rootAux.left, parentRootAux.left);
					} else {
						return deleteAux(pair.getKey(), rootAux.left, parentRootAux.right);
					}
				}

			} else {
				KeyValuePair<K, V> pair = getMaximumKeyValueAux(rootAux.left);
				Node newNode = new Node(pair.getKey(), pair.getValue());
				newNode.left = rootAux.left;
				newNode.right = rootAux.right;

				if (parentRootAux.left == rootAux) {
					parentRootAux.left = newNode;
				} else if (parentRootAux.right == rootAux) {
					parentRootAux.right = newNode;
				} else {
					this.root = newNode;
					parentRootAux = newNode;
				}

				rootAux = newNode;

				if (parentRootAux == rootAux) {
					return deleteAux(pair.getKey(), rootAux.left, parentRootAux);
				} else {

					if (parentRootAux.left == rootAux) {
						return deleteAux(pair.getKey(), rootAux.left, parentRootAux.left);
					} else {
						return deleteAux(pair.getKey(), rootAux.left, parentRootAux.right);
					}
				}
			}
		} else if (comparison < 0) {
			if (parentRootAux == rootAux) {
				return deleteAux(key, rootAux.left, parentRootAux);
			} else {
				if (parentRootAux.left == rootAux) {
					return deleteAux(key, rootAux.left, parentRootAux.left);
				} else {
					return deleteAux(key, rootAux.left, parentRootAux.right);
				}
			}
		} else {
			if (parentRootAux == rootAux) {
				return deleteAux(key, rootAux.right, parentRootAux);
			} else {
				if (parentRootAux.left == rootAux) {
					return deleteAux(key, rootAux.right, parentRootAux.left);
				} else {
					return deleteAux(key, rootAux.right, parentRootAux.right);
				}
			}
		}
	}

	public void processInorder(Callback<K, V> callback) {
		if (callback == null) {
			throw new IllegalArgumentException("STOP");
		}

		processInorderAux(callback, root);
	}

	private void processInorderAux(Callback<K, V> callback, Node rootAux) {
		if (callback == null) {
			throw new IllegalArgumentException("STOP");
		}
		if (rootAux == null) {
			return;
		}

		processInorderAux(callback, rootAux.left);
		callback.process(rootAux.key, rootAux.value);
		processInorderAux(callback, rootAux.right);
	}

	public BinarySearchTree<K, V> subTree(K lowerLimit, K upperLimit) {
		if (lowerLimit == null || upperLimit == null) {
			throw new IllegalArgumentException("STOP");
		}
		int comparison = comparator.compare(lowerLimit, upperLimit);

		if (comparison > 0) {
			throw new IllegalArgumentException("STOP");
		}

		return subTreeAux(lowerLimit, upperLimit, root, null, new BinarySearchTree<K, V>(comparator, maxEntries));
	}

	private BinarySearchTree<K, V> subTreeAux(K lowerLimit, K upperLimit, Node rootAux, Node subTreeRootAux,
			BinarySearchTree<K, V> subTree) {

		if (rootAux == null) {
			return subTree;
		}

		int lowerComp = comparator.compare(lowerLimit, rootAux.key);
		int upperComp = comparator.compare(upperLimit, rootAux.key);

		if (lowerComp > 0 && rootAux.right != null) {
			int lowerCompChild = comparator.compare(lowerLimit, rootAux.right.key);
			
			if(lowerCompChild <= 0) {
				subTree = subTreeAux(lowerLimit, upperLimit, rootAux.right, subTreeRootAux, subTree);
			}
		} else if (upperComp < 0 && rootAux.left != null) {
			int upperCompChild = comparator.compare(upperLimit, rootAux.left.key);
			
			if(upperCompChild >= 0) {
				subTree = subTreeAux(lowerLimit, upperLimit, rootAux.left, subTreeRootAux, subTree);
			}
		} else if(upperComp >= 0 && lowerComp <= 0){
			if (subTreeRootAux == null) {
				subTreeRootAux = new Node(rootAux.key, rootAux.value);
				subTree.root = subTreeRootAux;
				subTree.treeSize++;
				
				if(lowerComp != 0) {
					subTree = subTreeAux(lowerLimit, upperLimit, rootAux.left, subTreeRootAux, subTree);

				}
				if(upperComp != 0) {
					subTree = subTreeAux(lowerLimit, upperLimit, rootAux.right, subTreeRootAux, subTree);

				}
			} else {
				int nodesComp = comparator.compare(subTreeRootAux.key, rootAux.key);

				if (nodesComp < 0) {
					subTreeRootAux.right = new Node(rootAux.key, rootAux.value);
					subTree.treeSize++;
					if(lowerComp != 0) {
						subTree = subTreeAux(lowerLimit, upperLimit, rootAux.left, subTreeRootAux.right, subTree);

					}
					if(upperComp != 0) {
						subTree = subTreeAux(lowerLimit, upperLimit, rootAux.right, subTreeRootAux.right, subTree);

					}
				} else if (nodesComp > 0) {
					subTreeRootAux.left = new Node(rootAux.key, rootAux.value);
					subTree.treeSize++;
					if(lowerComp != 0) {
						subTree = subTreeAux(lowerLimit, upperLimit, rootAux.left, subTreeRootAux.left, subTree);

					}
					if(upperComp != 0) {
						subTree = subTreeAux(lowerLimit, upperLimit, rootAux.right, subTreeRootAux.left, subTree);

					}
				} else {
					subTreeRootAux.key = rootAux.key;
					if(lowerComp != 0) {
						subTree = subTreeAux(lowerLimit, upperLimit, rootAux.left, subTreeRootAux, subTree);

					}
					if(upperComp != 0) {
						subTree = subTreeAux(lowerLimit, upperLimit, rootAux.right, subTreeRootAux, subTree);

					}
				}
			}
		}
		return subTree;
	}

	public TreeSet<V> getLeavesValues() {
		TreeSet<V> treeSet = new TreeSet<V>();

		if (root == null) {
			return treeSet;
		} else {
			return getLeavesValuesAux(treeSet, root);
		}
	}

	private TreeSet<V> getLeavesValuesAux(TreeSet<V> treeSet, Node rootAux) {
		if (rootAux == null) {
			return treeSet;
		}

		treeSet = getLeavesValuesAux(treeSet, rootAux.left);

		if (rootAux.left == null && rootAux.right == null) {
			treeSet.add(rootAux.value);
		}

		treeSet = getLeavesValuesAux(treeSet, rootAux.right);

		return treeSet;
	}

}

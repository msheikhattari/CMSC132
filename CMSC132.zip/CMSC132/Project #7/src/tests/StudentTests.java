package tests;

import static org.junit.Assert.*;

import java.util.Comparator;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

/* The following directive executes tests in sorted order */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class StudentTests {
	
	/* Remove the following test and add your tests */
	@Test
	public void addingTest() {
		implementation.BinarySearchTree<String, Integer> tree =
				
		new implementation.BinarySearchTree<String, Integer>(new Comparator<String>() {
			public int compare(String o1, String o2) {
				return o1.compareTo(o2);
			}}, 10);
		
		try {

		tree.add("D", 1);
		tree.add("B", 1);
		tree.add("C", 1);
		tree.add("A", 1);
		tree.add("E", 1);
		tree.add("F", 1);
		tree.add("A", 0);
		tree.add("G", 1);
		tree.add("H", 1);
		tree.add("I", 1);
		tree.add("J", 1);
		
	
		
		}catch(implementation.TreeIsFullException e){
			
		}
		
		try {
		System.out.println(tree.getMinimumKeyValue().getKey());
		System.out.println(tree.getMinimumKeyValue().getValue());
		System.out.println(tree.getMaximumKeyValue().getKey());
		System.out.println(tree.getMaximumKeyValue().getValue());
		
		System.out.println(tree.find("G").getValue());
		System.out.println(tree.find("A").getValue());
		//tree.find("W").getValue();

		
		
	
		}catch(implementation.TreeIsEmptyException e) {
			
		}
	}
	
	@Test
	public void deleteTest() {
		implementation.BinarySearchTree<Integer, Integer> tree =
				
		new implementation.BinarySearchTree<Integer, Integer>(new Comparator<Integer>() {
			public int compare(Integer o1, Integer o2) {
				return o1.compareTo(o2);
			}}, 100);
		
		try {

		tree.add(30, 1);
		tree.add(18, 1);
		tree.add(54, 1);
		tree.add(16, 1);
		tree.add(20, 1);
		tree.add(51, 1);
		tree.add(66, 0);
		tree.add(15, 1);
		tree.add(17, 1);
		tree.add(19, 1);
		tree.add(21, 1);
		tree.add(45, 1);
		tree.add(52, 1);
		tree.add(65, 1);
		tree.add(73, 1);
		
	
		
		}catch(implementation.TreeIsFullException e){
			
		}
		
		try {
		tree.delete(15);
		tree.delete(16);
		tree.delete(21);
		tree.delete(20);
		tree.delete(18);
		tree.delete(30);
		tree.delete(17);
		tree.delete(51);
		tree.delete(66);
		tree.delete(65);
		tree.delete(45);
		tree.delete(54);
		tree.delete(52);
		tree.delete(73);
		tree.delete(100).delete(19);
	

		
		
	
		}catch(implementation.TreeIsEmptyException e) {
			
		}
	}
	
	@Test
	public void deleteTest2() {
		implementation.BinarySearchTree<Integer, Integer> tree =
				
		new implementation.BinarySearchTree<Integer, Integer>(new Comparator<Integer>() {
			public int compare(Integer o1, Integer o2) {
				return o1.compareTo(o2);
			}}, 100);
		
		try {

		tree.add(10, 1);
		tree.add(5, 1);
		tree.add(30, 1);
		tree.add(6, 1);
		

		implementation.BinarySearchTree<Integer, Integer> subTree =
				tree.subTree(6, 6);
		
		subTree.add(6, 6);
		
	
		
		}catch(implementation.TreeIsFullException e){
			
		}
		
		try {
		tree.delete(15);
		
	

		
		
	
		}catch(implementation.TreeIsEmptyException e) {
			
		}
	}
	
	@Test
	public void processTest() {
		implementation.BinarySearchTree<Integer, Integer> tree =
				
		new implementation.BinarySearchTree<Integer, Integer>(new Comparator<Integer>() {
			public int compare(Integer o1, Integer o2) {
				return o1.compareTo(o2);
			}}, 100);
		
		try {

		tree.add(30, 1);
		tree.add(18, 1);
		tree.add(54, 1);
		tree.add(16, 1);
		tree.add(20, 1);
		tree.add(51, 1);
		tree.add(66, 0);
		tree.add(15, 1);
		tree.add(17, 1);
		tree.add(19, 1);
		tree.add(21, 1);
		tree.add(45, 1);
		tree.add(52, 1);
		tree.add(65, 1);
		tree.add(73, 1);
		
	
		
		}catch(implementation.TreeIsFullException e){
			
		}
		
		try {
		implementation.GetDataIntoArrays<Integer, Integer> callback =
		new implementation.GetDataIntoArrays<Integer, Integer>();
	

		tree.processInorder(callback);
		
		System.out.println(callback.getKeys());
		
	
		}catch(IllegalArgumentException e) {
			
		}
	}
	
	@Test
	public void subTreeTest() {
		implementation.BinarySearchTree<Integer, Integer> tree =
				
		new implementation.BinarySearchTree<Integer, Integer>(new Comparator<Integer>() {
			public int compare(Integer o1, Integer o2) {
				return o1.compareTo(o2);
			}}, 100);
		
		try {
			tree.add(30, 1);
			tree.add(18, 1);
			tree.add(54, 1);
			tree.add(16, 1);
			tree.add(20, 1);
			tree.add(51, 1);
			tree.add(66, 0);
			tree.add(15, 1);
			tree.add(17, 1);
			tree.add(19, 1);
			tree.add(21, 1);
			tree.add(45, 1);
			tree.add(52, 1);
			tree.add(65, 1);
			tree.add(73, 1);

		
		
		implementation.BinarySearchTree<Integer, Integer> subTree =
				tree.subTree(18, 54);
		
		subTree.add(73, 1);
		
		}catch(implementation.TreeIsFullException e){
			
		}
		
	}
	
	@Test
	public void treeSetTest() {
		implementation.BinarySearchTree<Integer, Integer> tree =
				
		new implementation.BinarySearchTree<Integer, Integer>(new Comparator<Integer>() {
			public int compare(Integer o1, Integer o2) {
				return o1.compareTo(o2);
			}}, 100);
		
		try {
			tree.add(30, 1);
			tree.add(18, 2);
			tree.add(54, 3);
			tree.add(16, 4);
			tree.add(20, 5);
			tree.add(51, 6);
			tree.add(66, 7);
			tree.add(15, 8);
			tree.add(17, 9);
			tree.add(19, 10);
			tree.add(21, 11);
			tree.add(45, 12);
			tree.add(52, 13);
			tree.add(65, 14);
			tree.add(73, 15);
		
		
		java.util.TreeSet<Integer> treeSet = tree.getLeavesValues();
		
		treeSet.add(20000);
		
		}catch(implementation.TreeIsFullException e){
			
		}
		
	}
	
	
}

package model;

public class ImageElement extends TagElement implements Element {
	String imageURL, alt;
	int width, height;

	@Override
	public String genHTML(int indentation) {
		String spaces = "";
		int i;
		
		for(i = 0; i < indentation; i++) {
			spaces+= " ";
		}
		return spaces + this.getStartTag() + ((this.content == null) ? "" : 
			   this.content.genHTML(indentation)) + this.getEndTag();
	}
	
	public ImageElement(String imageURL, int width, int height, String alt, String attributes) {
		super("img", false, null, " src=\"" + imageURL + "\"" + " width=\"" + width 
			  + "\"" + " height=\"" + height + "\"" + " alt=\"" + alt + "\"" + 
				((attributes == null) ? "" : attributes));
		this.imageURL = imageURL;
		this.height = height;
		this.width = width;
		this.alt = alt;
	}
	
	public String getImageURL() {
		return imageURL;
	}

}

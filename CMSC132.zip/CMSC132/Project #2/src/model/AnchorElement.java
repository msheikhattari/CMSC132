package model;

public class AnchorElement extends TagElement implements Element {
	String URL;
	String linkText;

	@Override
	public String genHTML(int indentation) {
		String spaces = "";
		int i;
		
		for(i = 0; i < indentation; i++) {
			spaces+= " ";
		}
		return spaces + this.getStartTag() + ((this.content == null) ? "" : 
			   this.content.genHTML(indentation)) + this.getEndTag();
	}
	
	public AnchorElement(String URL, String linkText, String attributes) {
		super("a", true, new TextElement(linkText), " href=" + "\"" + URL + "\""  
				+ ((attributes == null) ? "" : attributes));
		this.linkText = linkText;
		this.URL = URL;
	}
	
	public String getLinkText() {
		return linkText;
	}
	
	public String getURLText() {
		return URL;
	}

}

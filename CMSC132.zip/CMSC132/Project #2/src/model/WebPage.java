package model;

import java.util.ArrayList;

public class WebPage implements Comparable<WebPage> {
	String title;
	public static boolean useID = true;
	private ArrayList<Element> elementList;
	
	public WebPage(String title) {
		this.title = title;
		elementList = new ArrayList<Element>();
	}
	
	public int addElement(Element element) {
		elementList.add(element);
		
		if(element instanceof TagElement) {
			return ((TagElement) element).getId();
		}else {
			return -1;
		}
	}
	
	public String getWebPageHTML(int indentation) {
		String HTML = "", spaces = "";
		
		for(int i = 0; i < indentation; i++) {
			spaces+= " ";
		}
		
		HTML += "<!doctype html>\n<html>\n" + spaces + "<head>\n" + spaces + spaces;
		HTML += "<meta charset=\"utf-8\"/>\n";
		HTML += spaces + spaces + "<title>" + title + "</title>\n";
		HTML += spaces + "</head>\n" + spaces + "<body>\n";
		
		for(int i =0; i < elementList.size(); i++) {
			HTML += elementList.get(i).genHTML(indentation);
			HTML += "\n";
		}
		
		HTML += spaces + "</body>\n";
		HTML += "</html>";
		
		return HTML;
	}
	
	public void writeToFile(String filename, int indentation) {
		Utilities.writeToFile(filename, getWebPageHTML(indentation));
	}
	
	public Element findElem(int id) {
		if(elementList.size() <= id) {
			return elementList.get(id);
		}else {
			return null;
		}
	}
	
	public String stats() {
		int list = 0, paragraph = 0, table = 0; 
		double utilization = 0;
		String stats = "";
		
		for(int i = 0; i < elementList.size(); i++) {
			if(elementList.get(i) instanceof TableElement) {
				table++;
			}else if(elementList.get(i) instanceof ParagraphElement) {
				paragraph++;
			}else if(elementList.get(i) instanceof ListElement) {
				list++;
			}
		}
		
		if(table > 0) {
			for(int i = 0; i < elementList.size(); i++) {
				if(elementList.get(i) instanceof TableElement) {
					utilization+= ((TableElement)elementList.get(i)).getTableUtilization();
				}
			}
			utilization/= table;
		}
		stats+= "List Count: " + list;
		stats+= "Paragraph Count: " + paragraph;
		stats+= "Table Count: " + table;
		stats+= "TableElement Utilization: " + utilization;

		return stats;
	}
	
	public int compareTo(WebPage WebPage) {
		if(this.title.compareTo(WebPage.title) > 0) {
			return 1;
		}else if(this.title.compareTo(WebPage.title) > 0) {
			return -1;
		}else {
			return 0;
		}
	}
	
	public static void enableId(boolean choice) {
		useID = choice;
	}

}

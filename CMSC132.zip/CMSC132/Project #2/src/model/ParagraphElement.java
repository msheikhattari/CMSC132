package model;
import java.util.*;

public class ParagraphElement extends TagElement implements Element {
	private ArrayList<Element> contentList;

	

	@Override
	public String genHTML(int indentation) {
		String HTML = "", spaces = "";
		int i;
		
		for(i = 0; i < indentation; i++) {
			spaces+= " ";
		}
		HTML += spaces + this.getStartTag() + "\n" + spaces;
		
		for(i = 0; i < contentList.size(); i++) {
			HTML+= spaces + contentList.get(i).genHTML(indentation) + "\n";
		}

		for(i = 0; i < indentation; i++) {
			HTML+= " ";
		}
		return HTML + ((this.content == null) ? "" : 
			   this.content.genHTML(indentation)) + this.getEndTag();
	}
	
	public ParagraphElement(String attributes) {
		super("p", true, null, attributes);
		this.contentList = new ArrayList<Element>();
	}
	
	public void addItem(Element item) {
		this.contentList.add(item);
	}

}

package model;

public class TableElement extends TagElement implements Element {
	Element[][] array;
	int rows, cols;

	@Override
	public String genHTML(int indentation) {
		String HTML = "", spaces = "";
		int i, j;
		
		for(i = 0; i < indentation; i++) {
			spaces+= " ";
		}
		HTML+= spaces + this.getStartTag() + "\n" ;
		
		for(i = 0; i < array.length; i++) {
			HTML+= spaces + spaces + "<tr>";
			for(j = 0; j < array[i].length; j++) {
				HTML+= "<td>";
				if(array[i][j] == null) {
					HTML+= "</td>";
				}else {
					HTML+= array[i][j].genHTML(indentation) + "</td>";
				}
				if(j == array[i].length - 1) {
					HTML+= "</tr>\n";
				}
			}
		}
		
		return HTML + ((this.content == null) ? "" : 
			   this.content.genHTML(indentation)) + spaces + this.getEndTag();
	}
	
	public TableElement(int rows, int cols, String attributes) {
		super("table", true, null, attributes);
		array = new Element[rows][cols];
		this.rows = rows;
		this.cols = cols;
	}
	
	public void addItem(int rowIndex, int colIndex, Element item) {
		array[rowIndex][colIndex] = item;
	}
	
	public double getTableUtilization() {
		double area = array.length * array[0].length, cellsUsed = 0, percent;
		int i, j;
		
		for(i =0; i < array.length; i++) {
			for(j=0; j < array[i].length; j++) {
				if(array[i][j] != null) {
					cellsUsed++;
				}
			}
		}
		percent = cellsUsed/area;
		return percent*100;
	}

}

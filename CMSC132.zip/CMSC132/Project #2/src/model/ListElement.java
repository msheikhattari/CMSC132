package model;

import java.util.ArrayList;

public class ListElement extends TagElement implements Element {
	private ArrayList<Element> contentList;
	
	
	@Override
	public String genHTML(int indentation) {
		String HTML = "", spaces = "";
		int i;
		
		for(i = 0; i < indentation; i++) {
			spaces+= " ";
		}
		HTML += spaces + this.getStartTag() + "\n" + spaces;
		
		for(i = 0; i < contentList.size(); i++) {
			HTML+= spaces + "<li>";
			HTML+= contentList.get(i).genHTML(indentation) + "\n";
			HTML+= spaces + spaces + "</li>" + spaces + "\n";
		}


		return HTML + ((this.content == null) ? "" : 
			   this.content.genHTML(indentation)) + spaces + this.getEndTag();
	}
	
	public ListElement(boolean ordered, String attributes) {
		super(((ordered == true) ? "ol" : "ul"), true, null, attributes);
		this.contentList = new ArrayList<Element>();
	}
	
	public void addItem(Element item) {
		contentList.add(item);
	}

}

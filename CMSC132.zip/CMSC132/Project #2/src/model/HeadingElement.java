package model;

public class HeadingElement extends TagElement implements Element {
	int level;

	@Override
	public String genHTML(int indentation) {
		String spaces = "";
		int i;
		
		for(i = 0; i < indentation; i++) {
			spaces+= " ";
		}
		return spaces + this.getStartTag() + ((this.content == null) ? "" : 
			   this.content.genHTML(indentation)) + this.getEndTag();

	}
	
	public HeadingElement(Element content, int level, String attributes) {
		super("h" + level, true, content, attributes);
	}
	

}

package model;

public class TextElement implements Element {
	private String text;

	public String genHTML(int indentation) {
		return "" + text;
	}
	
	public TextElement(String text) {
		this.text = text;
	}

}

package model;

public interface Element {

	public String genHTML(int indentation);
}

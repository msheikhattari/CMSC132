package model;

public class TagElement implements Element {
	private String tagName, attributes;
	private boolean endTag;
	public Element content;
	public static int idNumber = 1;
	private int id;
	public static boolean useID = true;

	@Override
	public String genHTML(int indentation) {
		String spaces = "";
		int i;
		
		for(i = 0; i < indentation; i++) {
			spaces+= " ";
		}
		return spaces + this.getStartTag() + ((this.content == null) ? "" : 
			   this.content.genHTML(indentation)) + this.getEndTag();
	}
	
	public TagElement(String tagName, boolean endTag, Element content, String attributes) {
		this.tagName = tagName;
		this.endTag = endTag; 
		this.content = content;
		if(attributes == null) {
			this.attributes = "";
		}else {
			this.attributes = attributes;
		}
		if(useID) {
			id = idNumber;
			idNumber++;
		}
	}
	
	public int getId() {
		return id;
	}
	
	public String getStringId() {
		if(useID) {
			return tagName + id;
		}else {
			return tagName;
		}
	}
	
	public String getStartTag() {
		if(useID) {
			return "<" + tagName + " id=\"" + this.getStringId() + "\"" +
					attributes + ">";
		}else {
			return "<" + tagName + attributes + ">";
		}
	}
	
	public String getEndTag() {
		if(endTag) {
			return "</" + tagName + ">";
		}else {
			return "";
		}
	}
	
	public void setAttributes(String attributes) {
		this.attributes = attributes;
	}
	
	public static void resetIds() {
		idNumber = 1;
	}
	
	public static void enableId(boolean choice) {
		useID = choice;
	}

}

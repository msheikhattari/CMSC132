package tests;

import static org.junit.Assert.*;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import model.ListElement;
import model.TableElement;
import model.TagElement;
import model.TextElement;
import model.WebPage;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class StudentTests {

	@Test
	public void webPageStatstest() {
		WebPage webPage = new WebPage("Example2");
		int indentation = 3;
		String answer = "";

		TagElement.resetIds();
		TagElement.enableId(false);
		TableElement tableElement = new TableElement(2, 2, null);
		tableElement.addItem(0, 0, new TextElement("Dog"));
		tableElement.addItem(1, 1, new TextElement("Cat"));
		webPage.addElement(tableElement);

		tableElement = new TableElement(2, 2, null);
		tableElement.addItem(0, 0, new TextElement("Red"));
		tableElement.addItem(0, 1, new TextElement("Blue"));
		tableElement.addItem(1, 0, new TextElement("Green"));
		tableElement.addItem(1, 1, new TextElement("Yellow"));
		webPage.addElement(tableElement);

		webPage.addElement(new ListElement(true, null));
		
		webPage.stats();
		
	}

}

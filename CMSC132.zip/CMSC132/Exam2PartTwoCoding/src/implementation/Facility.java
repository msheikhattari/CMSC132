package implementation;

import java.util.*;


public class Facility implements Iterable<String> {
	protected String name;

	protected class StorageUnit {
		public String unitId;
		public ArrayList<String> items;
		public StorageUnit next;
		public StorageUnit thread_next;

		public StorageUnit(String unitId) {
			this.unitId = unitId;
			this.items = new ArrayList<String>();
			next = null;
		}

		public void addItem(String singleItem) {
			items.add(singleItem);
		}
	}

	protected StorageUnit head;
	protected int totalUnits;
	protected StorageUnit thread_head;

	public Facility(String name) {
		if (Support.isValid(name)) {
			this.name = name;
			head = null;
			totalUnits = 0;
		}
	}

	public Facility() {
		this("NONAME");
	}

	public Facility addItemToStorageUnit(String unitId, String item) {
		if (Support.isValid(unitId) && Support.isValid(item)) {
			StorageUnit added = new StorageUnit(unitId);
			added.addItem(item);

			StorageUnit curr = head;

			if (head == null) {
				head = added;
				totalUnits++;
				return this;
			}

			while (curr != null) {
				if (curr.unitId.equals(unitId)) {
					curr.addItem(item);
					return this;
				}
				curr = curr.next;
			}

			curr = head;

			while (curr != null) {
				if (curr.next == null) {
					curr.next = added;
					totalUnits++;
					return this;
				}
				curr = curr.next;
			}
		}

		return this;
	}

	public int getTotalUnits() {
		return totalUnits;
	}

	public String getName() {
		return this.name;
	}

	/*
	 * You will lose credit if you use addItemToStorageUnit during the
	 * implementation of this method.
	 */
	public Facility getFacilityWithFirstUnit(String facilityName) {
		Facility returned = new Facility(facilityName);

		if (this.head == null) {
			return returned;
		}
		StorageUnit copied = new StorageUnit(this.head.unitId);
		copied.items.addAll(this.head.items);

		returned.head = copied;
		returned.totalUnits = 1;

		return returned;
	}

	/*
	 * Method must be implemented using recursion. You will lose credit if you use
	 * any iteration statement (e.g., for, while, do while).
	 */
	public int getTotalItemsInFacility() {
		if (head == null) {
			return 0;
		}
		return getTotalItemsInFacilityAuxiliary(0, head);
	}

	private int getTotalItemsInFacilityAuxiliary(int total, StorageUnit curr) {
		total += curr.items.size();

		if (curr.next == null) {
			return total;
		} else {
			return getTotalItemsInFacilityAuxiliary(total, curr.next);
		}
	}

	/*
	 * Method must be implemented using recursion. You will lose credit if you use
	 * any iteration statement (e.g., for, while, do while).
	 */
	public ArrayList<String> getItemsInUnitSorted(String unitId) {
		if (Support.isValid(unitId)) {
			return getItemsInUnitSortedAuxiliary(unitId, new ArrayList<String>(), head);
		}
		return getItemsInUnitSortedAuxiliary(unitId, new ArrayList<String>(), head);
	}

	private ArrayList<String> getItemsInUnitSortedAuxiliary(String unitId, ArrayList<String> list, StorageUnit curr) {
		if (head == null) {
			return list;
		}

		if (curr.unitId.equals(unitId)) {
			list.addAll(curr.items);
			Collections.sort(list);
			return list;
		}

		if (curr.next == null) {
			return list;
		}

		return getItemsInUnitSortedAuxiliary(unitId, list, curr.next);
	}

	public void setThread(int minimumItemsInUnit) {
		if(this.totalUnits == 0) {
			return;
		}
		thread_head = null;
		setThreadAuxiliary(minimumItemsInUnit, head, thread_head);	
	}
	
	private void setThreadAuxiliary(int minimumItemsInUnit, StorageUnit currOG, StorageUnit currThread) {
		if(currOG.items.size() >= minimumItemsInUnit) {
			if(thread_head == null) {
				thread_head = currOG;
				currThread = thread_head;
			}else {
				currThread.thread_next = currOG;
				currThread = currThread.thread_next;
			}
		}
		if(currOG.next == null) {
			return;
		}
		currOG = currOG.next;
		setThreadAuxiliary(minimumItemsInUnit, currOG, currThread);
	}

	public Iterator<String> iterator() {
		return new Iterator<String>() {
			int unitNum = 0;
			StorageUnit curr = head;

			public boolean hasNext() {
				return (curr != null && unitNum < 3);

			}

			public String next() {
				if (head == null || curr == null) {
					throw new NoSuchElementException();
				}

				String id = (curr.unitId);
				curr = curr.next;
				unitNum++;
				return id;
			}

			public void remove() {
				throw new UnsupportedOperationException();
			}

		};
	}

	/* Provided: Do not modify */
	public String toStringThreadedNodes() {
		String answer = "";

		if (thread_head == null) {
			answer = "NOT THREADED";
		} else {
			StorageUnit curr = thread_head;
			while (curr != null) {
				answer += "UnitId:" + curr.unitId + ", Items: " + curr.items + "\n";

				curr = curr.thread_next;
			}
		}

		return answer;
	}

	/* Provided: Do not modify */
	public String toString() {
		String answer = "Facility name: " + name + "\n";
		answer += "Total Units: " + totalUnits + "\n";
		StorageUnit curr = head;

		while (curr != null) {
			answer += "UnitId:" + curr.unitId + ", Items: " + curr.items + "\n";

			curr = curr.next;
		}

		return answer;
	}
}

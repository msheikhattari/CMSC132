package tests;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Iterator;

import org.junit.Test;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import implementation.*;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class StudentTests {
    @Test
    public void facilityConstructorsTest() {
    	Facility facility = new Facility("APE");
    	
    	Facility dumb = new Facility();
    	
    	//Facility fail = new Facility(null);
    	
    	System.out.println(facility.getName());
    	System.out.println(facility.getTotalUnits());
    }
    
    @Test
    public void facilityAddingToFirstTest() {
    	Facility facility = new Facility("APE");
    	
    	facility.addItemToStorageUnit("0", "AngryBird");
    	facility.addItemToStorageUnit("0", "Apple");
    	facility.addItemToStorageUnit("0", "Orange");
    	
    }
    
    @Test
    public void facilityAddingMultipleTest() {
    	Facility facility = new Facility("APE");
    	
    	facility.addItemToStorageUnit("0", "AngryBird");
    	facility.addItemToStorageUnit("1", "Apple");
    	facility.addItemToStorageUnit("2", "Orange");
    	facility.addItemToStorageUnit("3", "PoopyPoopyPoopers");
    	facility.addItemToStorageUnit("4", "Ankles");
    	facility.addItemToStorageUnit("3", "Bone");
    	
    	
    }
    
    @Test
    public void getFacilityWithFirstUnitTest() {
    	Facility facility = new Facility("APE");
    	
    	facility.addItemToStorageUnit("0", "AngryBird");
    	facility.addItemToStorageUnit("1", "Apple");
    	facility.addItemToStorageUnit("2", "Orange");
    	facility.addItemToStorageUnit("3", "PoopyPoopyPoopers");
    	facility.addItemToStorageUnit("4", "Ankles");
    	facility.addItemToStorageUnit("3", "Bone");
    	facility.addItemToStorageUnit("0", "PoopyPoopyPoopers");
    	facility.addItemToStorageUnit("0", "Ankles");
    	facility.addItemToStorageUnit("0", "Bone");
    	
    	Facility firstCopy = facility.getFacilityWithFirstUnit("APE2.0");
    	
    	firstCopy.addItemToStorageUnit("0", "TESTTESTTEST");
    	facility.addItemToStorageUnit("0", "BOOP");
    	
    }
    @Test
    public void getFacilityWithFirstUnitEMPTYTest() {
    	Facility facility = new Facility("APE");
    	

    	
    	Facility firstCopy = facility.getFacilityWithFirstUnit("APE2.0");

    	firstCopy.addItemToStorageUnit("0", "TESTTESTTEST");
    	facility.addItemToStorageUnit("0", "BOOP");
    }
    
    @Test
    public void getTotalItemsInFacilityTest() {
    	Facility facility = new Facility("APE");
    	
    	facility.addItemToStorageUnit("0", "AngryBird");
    	facility.addItemToStorageUnit("1", "Apple");
    	facility.addItemToStorageUnit("2", "Orange");
    	facility.addItemToStorageUnit("3", "PoopyPoopyPoopers");
    	facility.addItemToStorageUnit("4", "Ankles");
    	facility.addItemToStorageUnit("3", "Bone");
    	facility.addItemToStorageUnit("0", "PoopyPoopyPoopers");
    	facility.addItemToStorageUnit("0", "Ankles");
    	facility.addItemToStorageUnit("0", "Bone");
    	
    	Facility firstCopy = facility.getFacilityWithFirstUnit("APE2.0");
    	
    	firstCopy.addItemToStorageUnit("0", "TESTTESTTEST");
    	facility.addItemToStorageUnit("0", "BOOP");
    	
    	
    	System.out.println(facility.getTotalItemsInFacility());
    	System.out.println(firstCopy.getTotalItemsInFacility());

    	
    }
    @Test
    public void getTotalItemsInFacilityEMPTYTest() {
    	Facility facility = new Facility("APE");
    	
    	System.out.println(facility.getTotalItemsInFacility());

    	
    }
    
    @Test
    public void getItemsInUnitSortedTest() {
    	Facility facility = new Facility("APE");
    	
    	facility.addItemToStorageUnit("0", "AngryBird");
    	facility.addItemToStorageUnit("1", "Apple");
    	facility.addItemToStorageUnit("2", "Orange");
    	facility.addItemToStorageUnit("3", "PoopyPoopyPoopers");
    	facility.addItemToStorageUnit("4", "Ankles");
    	facility.addItemToStorageUnit("3", "Bone");
    	facility.addItemToStorageUnit("0", "PoopyPoopyPoopers");
    	facility.addItemToStorageUnit("0", "Ankles");
    	facility.addItemToStorageUnit("0", "Bone");
    	
    	ArrayList<String> list = facility.getItemsInUnitSorted("0");
    }
    
    @Test
    public void getItemsInUnitSortedOneUnitNoMatchTest() {
    	Facility facility = new Facility("APE");
    	
    	facility.addItemToStorageUnit("0", "AngryBird");
    	facility.addItemToStorageUnit("0", "PoopyPoopyPoopers");
    	facility.addItemToStorageUnit("0", "Ankles");
    	facility.addItemToStorageUnit("0", "Bone");
    	
    	ArrayList<String> list = facility.getItemsInUnitSorted("1");
    }
    
    @Test
    public void getItemsInUnitSortedEmptyTest() {
    	Facility facility = new Facility("APE");
    	
    	ArrayList<String> list = facility.getItemsInUnitSorted("1");
    }
    @Test
    public void getItemsInUnitSortedLastOneTest() {
    	Facility facility = new Facility("APE");
    	
    	facility.addItemToStorageUnit("0", "AngryBird");
    	facility.addItemToStorageUnit("1", "Apple");
    	facility.addItemToStorageUnit("2", "Orange");
    	facility.addItemToStorageUnit("3", "PoopyPoopyPoopers");
    	facility.addItemToStorageUnit("4", "Ankles");
    	facility.addItemToStorageUnit("3", "Bone");
    	facility.addItemToStorageUnit("0", "PoopyPoopyPoopers");
    	facility.addItemToStorageUnit("0", "Ankles");
    	facility.addItemToStorageUnit("0", "Bone");
    	
    	ArrayList<String> list = facility.getItemsInUnitSorted("4");
    }
    
    @Test
    public void setThreadTest() {
    	Facility facility = new Facility("APE");
    	
    	facility.addItemToStorageUnit("0", "AngryBird");
    	facility.addItemToStorageUnit("1", "Apple");
    	facility.addItemToStorageUnit("2", "Orange");
    	facility.addItemToStorageUnit("3", "PoopyPoopyPoopers");
    	facility.addItemToStorageUnit("4", "Ankles");
    	facility.addItemToStorageUnit("3", "Bone");
    	facility.addItemToStorageUnit("0", "PoopyPoopyPoopers");
    	facility.addItemToStorageUnit("0", "Ankles");
    	facility.addItemToStorageUnit("0", "Bone");
    	
    	facility.setThread(2);
    	
    	System.out.println(facility.toStringThreadedNodes());
    }
    
    @Test
    public void setThreadNoneFoundTest() {
    	Facility facility = new Facility("APE");
    	
    	facility.addItemToStorageUnit("0", "AngryBird");
    	facility.addItemToStorageUnit("1", "Apple");
    	facility.addItemToStorageUnit("2", "Orange");
    	facility.addItemToStorageUnit("3", "PoopyPoopyPoopers");
    	facility.addItemToStorageUnit("4", "Ankles");
    	facility.addItemToStorageUnit("3", "Bone");
    	facility.addItemToStorageUnit("0", "PoopyPoopyPoopers");
    	facility.addItemToStorageUnit("0", "Ankles");
    	facility.addItemToStorageUnit("0", "Bone");
    	
    	facility.setThread(5);
    	
    	System.out.println(facility.toStringThreadedNodes());
    }
    @Test
    public void setThreadNotFirstTest() {
    	Facility facility = new Facility("APE");
    	
    	facility.addItemToStorageUnit("0", "AngryBird");
    	facility.addItemToStorageUnit("1", "Apple");
    	facility.addItemToStorageUnit("2", "Orange");
    	facility.addItemToStorageUnit("3", "PoopyPoopyPoopers");
    	facility.addItemToStorageUnit("4", "Ankles");
    	facility.addItemToStorageUnit("3", "Bone");

    	
    	facility.setThread(1);
    	
    	System.out.println(facility.toStringThreadedNodes());
    }
    
    @Test
    public void facilityIteratorTest() {
    	Facility facility = new Facility("APE");
    	
    	facility.addItemToStorageUnit("0", "AngryBird");
    	facility.addItemToStorageUnit("1", "Apple");
    	facility.addItemToStorageUnit("2", "Orange");
    	facility.addItemToStorageUnit("3", "PoopyPoopyPoopers");
    	facility.addItemToStorageUnit("4", "Ankles");
    	facility.addItemToStorageUnit("3", "Bone");
    	
        Iterator<String> iterator = facility.iterator();
    	System.out.println("Iterator output:");
    	while (iterator.hasNext()) {
    		System.out.println(iterator.next());
    	}
    	
    	
    }
    

    
    
}
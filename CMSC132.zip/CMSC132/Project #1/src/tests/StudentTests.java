package tests;

import static org.junit.Assert.*;

import java.util.*;

import org.junit.Test;

import tubeVideosManager.Video;

/**
 * 
 * You need student tests if you are asking for help during office hours about
 * bugs in your code. Feel free to use tools available in TestingSupport.java
 * 
 * @author UMCP CS Department
 *
 */
public class StudentTests {

	@Test
	public void playlistConstructorAndGetNameTest() {
		tubeVideosManager.Playlist playlist = new tubeVideosManager.Playlist("Jeff");

		System.out.println(playlist.getName());
	}

	@Test
	public void copyPlaylistAndAddToPlaylistAndGetPlaylistVideosTitlesTest() {
		tubeVideosManager.Playlist playlist = new tubeVideosManager.Playlist("Jeff");
		tubeVideosManager.Playlist copy = new tubeVideosManager.Playlist(playlist);
		copy.addToPlaylist("Rihanna");

		System.out.println(playlist.getPlaylistVideosTitles());
	}

	@Test
	public void removeFromPlaylistAllTest() {
		tubeVideosManager.Playlist playlist = new tubeVideosManager.Playlist("Jeff");

		playlist.addToPlaylist("Jeff");
		playlist.addToPlaylist("Man");
		playlist.addToPlaylist("Jeff");

		playlist.removeFromPlaylistAll("Jeff");

		System.out.println(playlist.getPlaylistVideosTitles());
	}

	@Test
	public void shuffleVideoTitlesTest() {
		tubeVideosManager.Playlist playlist = new tubeVideosManager.Playlist("Jeff");

		playlist.addToPlaylist("Jeff");
		playlist.addToPlaylist("Man");
		playlist.addToPlaylist("Kat");

		Random random = new Random();

		playlist.shuffleVideoTitles(random);

		System.out.println(playlist.getPlaylistVideosTitles());
	}

	@Test
	public void videoConstructorAndGettersAndCommentsTest() {
		tubeVideosManager.Video video = new tubeVideosManager.Video("Mya Cuhleafuh",
				"www.youtub.com", 10, tubeVideosManager.Genre.Comedy);
		video.addComments("Cool");

		System.out.println(video.getDurationInMinutes());
		System.out.println(video.getTitle());
		System.out.println(video.getUrl());
		System.out.println(video.getComments());
		System.out.println(video.getGenre());
	}

	@Test
	public void videoCopyConstructorTest() {
		tubeVideosManager.Video video = new tubeVideosManager.Video("Mya Cuhleafuh",
				"www.youtub.com", 10, tubeVideosManager.Genre.Comedy);
		tubeVideosManager.Video copy = new tubeVideosManager.Video(video);

		copy.addComments("Hi");

		System.out.println(video.getComments());
		System.out.println(copy.getComments());
	}

	@Test
	public void videoCompareToAndEqualsTest() {
		tubeVideosManager.Video video = new tubeVideosManager.Video("Mya Cuhleafuh", 
				"www.youtub.com", 10, tubeVideosManager.Genre.Comedy);
		tubeVideosManager.Video copy = new tubeVideosManager.Video("Apple", "w", 4, 
										tubeVideosManager.Genre.Comedy);

		System.out.println(copy.compareTo(video));
		System.out.println(copy.equals(video));
	}

	@Test
	public void addVideosToDBTest() {
		tubeVideosManager.TubeVideosManager manager = new tubeVideosManager.TubeVideosManager();

		manager.addVideoToDB("Mya Cuhleafuh", "www.youtub.com", 10, tubeVideosManager.Genre.Comedy);
	}

	@Test
	public void getAllVideosInDBTest() {
		tubeVideosManager.TubeVideosManager manager = new tubeVideosManager.TubeVideosManager();

		manager.addVideoToDB("Mya Cuhleafuh", "www.youtub.com", 10, tubeVideosManager.Genre.Comedy);

		ArrayList<Video> copyDB = manager.getAllVideosInDB();

		copyDB.add(new Video("Mya Cuhleafuh", "www.youtub.com", 10, tubeVideosManager.Genre.Comedy));
	}

	@Test
	public void findVideoTest() {
		tubeVideosManager.TubeVideosManager manager = new tubeVideosManager.TubeVideosManager();

		manager.addVideoToDB("Mya Cuhleafuh", "www.youtub.com", 10, tubeVideosManager.Genre.Comedy);

		Video found = manager.findVideo("Mya Cuhleafuh");
		Video notFound = manager.findVideo("Scoopy Doo");
	}

	@Test
	public void addCommentsDBTest() {
		tubeVideosManager.TubeVideosManager manager = new tubeVideosManager.TubeVideosManager();

		manager.addVideoToDB("Mya Cuhleafuh", "www.youtub.com", 10, tubeVideosManager.Genre.Comedy);

		manager.addComments("Mya Cuhleafuh", "Hi");
		manager.addComments("Asper", "p");
	}

	@Test
	public void addPlaylistDBTest() {
		tubeVideosManager.TubeVideosManager manager = new tubeVideosManager.TubeVideosManager();

		manager.addPlaylist("Apple");
		manager.addPlaylist("Orange");
		manager.addPlaylist("Apple");
	}

	@Test
	public void getPlaylistNamesTest() {
		tubeVideosManager.TubeVideosManager manager = new tubeVideosManager.TubeVideosManager();

		manager.addPlaylist("Apple");
		manager.addPlaylist("Orange");
		manager.addPlaylist("Apple");

		System.out.println(manager.getPlaylistsNames());
	}

	@Test
	public void addVideoToPlaylistTest() {
		tubeVideosManager.TubeVideosManager manager = new tubeVideosManager.TubeVideosManager();

		manager.addPlaylist("Apple");
		manager.addVideoToDB("Steve", "w", 10, tubeVideosManager.Genre.Comedy);
		manager.addVideoToPlaylist("Steve", "Apple");
	}

	@Test
	public void getPlaylistTest() {
		tubeVideosManager.TubeVideosManager manager = new tubeVideosManager.TubeVideosManager();

		manager.addPlaylist("Apple");
		manager.addVideoToDB("Steve", "w", 10, tubeVideosManager.Genre.Comedy);
		manager.addVideoToPlaylist("Steve", "Apple");

		tubeVideosManager.Playlist playlist = manager.getPlaylist("Apple");
	}

	@Test
	public void clearDBTest() {
		tubeVideosManager.TubeVideosManager manager = new tubeVideosManager.TubeVideosManager();

		manager.addPlaylist("Apple");
		manager.addVideoToDB("Steve", "w", 10, tubeVideosManager.Genre.Comedy);
		manager.addVideoToPlaylist("Steve", "Apple");

		manager.clearDatabase();
	}

	@Test
	public void searchForVideosTest() {
		tubeVideosManager.TubeVideosManager manager = new tubeVideosManager.TubeVideosManager();

		manager.addVideoToDB("Steve", "w", 10, tubeVideosManager.Genre.Comedy);
		tubeVideosManager.Playlist playlist = manager.searchForVideos("Apple", 
				"Steve", 11, tubeVideosManager.Genre.Comedy);
	}
}

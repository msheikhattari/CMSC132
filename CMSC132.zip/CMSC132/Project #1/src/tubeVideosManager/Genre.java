package tubeVideosManager;

/**
 * Provided; please don't modify.
 * Enumerated type representing the different video genre we
 * can have.
 * 
 * @author UMCP CS Department
 *
 */
public enum Genre {
	Comedy, Educational, Documentary, Music, FilmAnimation
}

import java.util.*;

public class Interest {

	public static float simpleInterest(float principal, float rate, int years) {
		return principal + (principal * (rate/100) * years);
	}
	
	public static float compoundInterest(float principal, float rate, int years) {
		return principal * (float) Math.pow(1 + rate/100,years);
	}
	
}

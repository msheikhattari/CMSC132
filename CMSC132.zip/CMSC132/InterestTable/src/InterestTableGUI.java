import javafx.application.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Slider;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class InterestTableGUI extends Application {
	
	public void start(Stage primaryStage) {
		int sceneWidth = 600, sceneHeight = 350;
		int verSpaceBetweenNodes = 8, horSpaceBetweenNodes = 8;
		int paneBorderTop = 5, paneBorderRight = 20;
		int paneBorderBottom = 5, paneBorderLeft = 20;
		
		//Scrollable area
		
		TextArea displayArea = new TextArea();
		displayArea.setEditable(false);
		displayArea.setWrapText(true);
		displayArea.setPrefSize(sceneWidth, sceneHeight / 3);
	
		
		
		
		/* Adding scroll pane to text area */
		ScrollPane scrollPane = new ScrollPane(displayArea);
		

		
		

		
		


		
		
		//gridpane of labels/textfields
		
		GridPane pane = new GridPane();
		pane.setHgap(horSpaceBetweenNodes);
		pane.setVgap(verSpaceBetweenNodes);
		pane.setPadding(new Insets(paneBorderTop, paneBorderRight, 
					    paneBorderBottom, paneBorderLeft));
		
		/* Adding GUI elements to the pane */
		Label principalLabel = new Label("Principal: ");
		TextField principal = new TextField();
		pane.add(principalLabel, 0, 0);
		pane.add(principal, 1, 0);
		
		Label rateLabel = new Label("Rate(Percentage): ");
		TextField rate = new TextField();
		
		pane.add(rateLabel, 2, 0);
		pane.add(rate, 3, 0);
		
		//gridpane of buttons
		
		GridPane pane2 = new GridPane();
		pane2.setHgap(horSpaceBetweenNodes);
		pane2.setVgap(verSpaceBetweenNodes);
		pane2.setPadding(new Insets(paneBorderTop, paneBorderRight, 
					    paneBorderBottom, paneBorderLeft));
		
		Button button = new Button("SimpleInterest");
		
		Button button2 = new Button("CompoundInterest");
		Button button3 = new Button("BothInterests");
		
		
		pane2.add(button, 0, 0);
		pane2.add(button2, 1, 0);
		pane2.add(button3, 2, 0);
		
		Slider horizontalSlider = new Slider();
		horizontalSlider.setMin(1);
		horizontalSlider.setMax(25);
		horizontalSlider.setValue(25);
		horizontalSlider.setMajorTickUnit(4);
		horizontalSlider.setShowTickMarks(true);
		horizontalSlider.setShowTickLabels(true);
		horizontalSlider.setPrefWidth(300);

		
		
		//adding slider to gridpane with label.
		GridPane pane3 = new GridPane();
		pane3.setHgap(horSpaceBetweenNodes);
		pane3.setVgap(verSpaceBetweenNodes);
		pane3.setPadding(new Insets(paneBorderTop, paneBorderRight, 
					    paneBorderBottom, paneBorderLeft));
		
		Label sliderLabel = new Label("		Number of Years: ");
		
		
		pane3.add(sliderLabel, 0, 0);
		
		pane3.add(horizontalSlider, 1, 0);
		
		
		
		BorderPane borderPane = new BorderPane();
		
		FlowPane flowPane = new FlowPane();
		flowPane.setHgap(horSpaceBetweenNodes);
		flowPane.setVgap(8);
		flowPane.setPadding(new Insets(paneBorderTop, paneBorderRight, 
					    paneBorderBottom, paneBorderLeft));

		flowPane.getChildren().add(pane);
		
		flowPane.getChildren().add(pane3);

		flowPane.getChildren().add(pane2);
		
		
		
		//Adding panes to the border pane
		
		//borderPane.setTop(displayArea);
		
		borderPane.setCenter(displayArea);
		
		borderPane.setBottom(flowPane);
		

		
		//SIMPLEINTEREST Anonymous class event handler
		button.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				float principalValue = Float.parseFloat(principal.getText());
				float rateValue = Float.parseFloat(rate.getText());
				int yearValue = (int)horizontalSlider.getValue();
				
				StringBuffer displayText = new StringBuffer("Principal: $" + principalValue);
				displayText.append(" Rate: " + rateValue + "\n");
				displayText.append("Year, Simple Interest Amount\n");
				
				for(int i = 1; i < yearValue + 1; i++) {
					String amount = String.format("%.2f", Interest.simpleInterest(principalValue, rateValue, i));
					
					displayText.append(i + "-->$" + amount + "\n");
				}
				
				
				
				displayArea.setText(new String(displayText));
			}
		});
		
		
		//COMPOUNDINTEREST Non-Anonymous class event handler
		final class ButtonHandler implements EventHandler<ActionEvent> {
			@Override
			public void handle(ActionEvent e) {
				float principalValue = Float.parseFloat(principal.getText());
				float rateValue = Float.parseFloat(rate.getText());
				int yearValue = (int)horizontalSlider.getValue();
				
				StringBuffer displayText = new StringBuffer("Principal: $" + principalValue);
				displayText.append(" Rate: " + rateValue + "\n");
				displayText.append("Year, Simple Interest Amount\n");
				
				for(int i = 1; i < yearValue + 1; i++) {
					String amount = String.format("%.2f", Interest.compoundInterest(principalValue, rateValue, i));
					
					displayText.append(i + "-->$" + amount + "\n");
				}
				
				
				
				displayArea.setText(new String(displayText));
			}
		}
		
		button2.setOnAction(new ButtonHandler());
		
		
		
		
		
		//BOTHINTEREST Lambda expression event handler
		
		button3.setOnAction(e -> {
			float principalValue = Float.parseFloat(principal.getText());
			float rateValue = Float.parseFloat(rate.getText());
			int yearValue = (int)horizontalSlider.getValue();
			
			StringBuffer displayText = new StringBuffer("Principal: $" + principalValue);
			displayText.append(" Rate: " + rateValue + "\n");
			displayText.append("Year, Simple Interest Amount, Compound Interest Amount\n");
			
			for(int i = 1; i < yearValue + 1; i++) {
				String simple = String.format("%.2f", Interest.simpleInterest(principalValue, rateValue, i));
				String compound = String.format("%.2f", Interest.compoundInterest(principalValue, rateValue, i));
				
				displayText.append(i + "-->$" + simple + "-->" + compound + "\n");
			}
			
			
			
			displayArea.setText(new String(displayText));
		});
		
		
		
		
		
		Scene scene = new Scene(borderPane, sceneWidth, sceneHeight);
		primaryStage.setTitle("Interest Table Calculator");
		primaryStage.setScene(scene);
		primaryStage.show();
	
		
		
		
		
		
	}
	

	public static void main(String[] args) {
		Application.launch(args);

	}

}

package implementation;

import java.util.*;

public class FlightsDatabase {
	private Map<String, Map<String, Integer>> flights;
	private String name;

	public FlightsDatabase(String name) {
		this.name = name;
		flights = new TreeMap<String, Map<String, Integer>>();
	}

	public FlightsDatabase() {
		this.name = "NONAME";
		flights = new TreeMap<String, Map<String, Integer>>();
	}

	public String getName() {
		return name;
	}

	public boolean isEmpty() {
		if (flights.isEmpty()) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (((FlightsDatabase) this).name.equals(((FlightsDatabase) obj).name)) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public int hashCode() {
		return name.hashCode();
	}

	public FlightsDatabase addFlight(String from, String destination, int flightCost) {
		if (from.equals(destination)) {
			return this;
		}

		TreeMap<String, Integer> to = new TreeMap<String, Integer>();
		to.put(destination, flightCost);

		if (flights.containsKey(from)) {
			flights.get(from).put(destination, flightCost);
			return this;
		} else {
			flights.put(from, to);
			return this;
		}

	}

	public int getNumberOfFlightsFrom(String from) {
		if (flights.containsKey(from)) {
			return flights.get(from).size();
		} else {
			return 0;
		}
	}

	public TreeSet<String> getDestinationsFrom(String from) {
		TreeSet<String> destinations = new TreeSet<String>();

		if (flights.containsKey(from)) {
			Set<String> toSet = flights.get(from).keySet();

			for (String x : toSet) {
				destinations.add(x);
			}
		}

		return destinations;

	}

	public int getDirectFlightCost(String from, String destination) {
		if (flights.containsKey(from)) {
			if (flights.get(from).containsKey(destination)) {
				return flights.get(from).get(destination);
			}
		}
		return -1;
	}

	public TreeSet<String> getAllFromAndDestinationsInDatabase() {
		TreeSet<String> all = new TreeSet<String>();
		Set<String> fromSet = flights.keySet();

		if (flights.size() > 0) {
			for (String x : fromSet) {
				all.add(x);

				if (flights.get(x).size() > 0) {
					Set<String> toSet = flights.get(x).keySet();

					for (String y : toSet) {
						all.add(y);
					}
				}
			}
		}
		
		return all;

	}

	/* Provided: do not modify */
	public String toString() {
		if (flights.size() == 0) {
			return "No Flights";
		} else {
			return flights.toString();
		}
	}
}

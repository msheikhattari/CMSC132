package tests;

import static org.junit.Assert.*;
import java.util.*;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

/* The following directive executes tests in sorted order */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class StudentTests {
	
	/* Remove the following test and add your tests */
	@Test
	public void test1() {
		implementation.FlightsDatabase db1 = new implementation.FlightsDatabase();
		implementation.FlightsDatabase db2 = new implementation.FlightsDatabase();

		System.out.println(db1.equals(db2));
		System.out.println(db1.hashCode());
		System.out.println(db2.hashCode());
		
		db1.addFlight("ID", "KS", 100);
		db1.addFlight("ID", "UT", 20);
		db1.addFlight("ID", "UT", 0);
		
		System.out.println(db1.getNumberOfFlightsFrom("ID"));
		System.out.println(db2.getNumberOfFlightsFrom("ID"));
		
		TreeSet<String> db1Dest = db1.getDestinationsFrom("ID");
		TreeSet<String> db2Dest = db2.getDestinationsFrom("ID");

		System.out.println(db1.getDirectFlightCost("ID", "KS"));
		System.out.println(db1.getDirectFlightCost("ID", "UT"));
		System.out.println(db1.getDirectFlightCost("NONE", "UT"));

		


		
	}
}

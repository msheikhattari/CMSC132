package tests;

import static org.junit.Assert.*;
import java.util.*;
import org.junit.Test;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import implementation.*;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class StudentTests {
    @Test
    public void sectionTest() {
           Section section = new Section(12);
           section.add("Momo");
           section.add("Michael");
           section.add("Harrison");
           
           Section section2 = new Section(12);
           Section section3 = new Section(14);
           Section section4 = new Section(-2);
           Section section5 = new Section(0);
           
           ArrayList<Section> sList = new ArrayList<Section>();
           sList.add(section);
           sList.add(section2);
           sList.add(section3);
           sList.add(section4);
           sList.add(section5);
           
           Collections.sort(sList);
           
           System.out.println(section.getEnrollment());
           System.out.println(section.getSectionNumber());
           System.out.println(section.equals(section2));
           System.out.println(section.equals(section3));
           
           System.out.println(section.hashCode());
           System.out.println(section2.hashCode());
           System.out.println(section3.hashCode());
           
           Section sectionCopy = section.clone();
           section.add("James");
           
           HonorSection hSection = new HonorSection(12, "James");
           System.out.println(hSection.getTAName());
           
           
           TreeSet<String> sorted = (TreeSet<String>)section.getStudents(true);
           HashSet<String> unSorted = (HashSet<String>)section.getStudents(false);
           
    }
    
    @Test
    public void courseTest() {
        Course course = new Course();
        course.addSection(12, null);
        course.addSection(14, "Alfred");
        course.addSection(6, "Jerome");
        course.addSection(-2, null);
        course.addSection(2, null).addSection(14, "Jeff");
        
        System.out.println(course);
        try {
        	Course course2 = new Course();
            //course2.addStudent(12, "Fred");
	        //course.addStudent(100, "Jeremy");
	        course.addStudent(0, "Fred");
	        course.addStudent(0, "Novel");
	        course.addStudent(12, "James");
	        course.addStudent(2, "Jerry");
	        
	        
	        TreeMap<Integer, Integer> enrollment = new TreeMap<Integer, Integer>();
	        
	        System.out.println(course.getEnrollmentPerSection(enrollment));
	        System.out.println(course2.getEnrollmentPerSection(enrollment));
	        
	        ArrayList<String> taList = course.getTAsHonorsSections();
	        taList = course2.getTAsHonorsSections();
	        
	        course.removeSection(14);
	        course.removeSection(12);
	        course.removeSection(2);
	   
	        
	        System.out.println(2);
	        
        }catch(IllegalArgumentException e) {
        	
        }
        
    	
    }
    
    @Test
    public void bstTest() {
    	GetKeysValuesTask<Integer, String> task = new GetKeysValuesTask<>();
    	BinarySearchTree<Integer, String> tree = new BinarySearchTree<Integer, String>();
    	tree.add(71, "y");
		tree.add(63, "y");
		tree.add(85, "y");
		tree.add(47, "y");
		tree.add(66, "n");
		tree.add(84, "n");
		tree.add(87, "n");
		tree.add(32, "n");
		tree.add(52, "n");
		
		tree.processNodesTwoChildren(task);
		System.out.println("Processing for Nodes Two Children: " + task.getData() + "\n");
		
		HashSet<Integer> l3 = (HashSet<Integer>)tree.getKeysNodesLevel(3);
				
		int targetKey = 100;
		ArrayList<Integer> path = tree.getPathKeysToFind(targetKey);
		
		System.out.println(2);
    }
    
    
    
}
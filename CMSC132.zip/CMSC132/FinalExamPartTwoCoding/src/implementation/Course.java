package implementation;

import java.util.*;

public class Course {
	protected class Node {
		public Section section;
		public Node next;

		protected Node(Section section) {
			this.section = section;
			next = null;
		}
	}

	protected Node head;

	public Course() {
		head = null;
	}

	public Course addSection(int sectionNumber, String taName) {
		Node curr = head;
		if(curr != null) {
			while(curr != null){
				if(curr.section.getSectionNumber() == sectionNumber) {
					return this;
				}
				curr = curr.next;
			}
		}
		
		Section section;
		
		if(taName == null) {
			section = new Section(sectionNumber);
		}else {
			section = new HonorSection(sectionNumber, taName);
		}
		curr = head;
		if(curr != null) {
			while(curr != null) {
				if(curr.next == null) {
					curr.next = new Node(section);
					return this;
				}
				curr = curr.next;
			}
		}else {
			head = new Node(section);
			return this;
		}
		return this;
		
	}

	public Course addStudent(int sectionNumber, String student) {
		
		Node curr = head;
		while(curr != null) {
			if(curr.section.getSectionNumber() == sectionNumber) {
				curr.section.add(student);
				return this;
			}
			curr = curr.next;
		}
	
		if(sectionNumber != 0 || head == null) {
			throw new IllegalArgumentException("STOP");
		}
		
		curr = head;
		int min = Integer.MAX_VALUE;
		Section section = new Section(min);
		while(curr != null) {
			if(curr.section.getEnrollment() < min) {
				min = curr.section.getEnrollment();
				section = curr.section;
			}
			curr = curr.next;
		}
		section.add(student);
		return this;
	}

	public int getEnrollmentPerSection(TreeMap<Integer, Integer> answer) {
		answer.clear();
		Node curr = head;
		int total = 0;
		
		while(curr != null) {
			answer.put(curr.section.getSectionNumber(), curr.section.getEnrollment());
			total += curr.section.getEnrollment();
			
			curr = curr.next;
		}
		
		return total;
	}

	public ArrayList<String> getTAsHonorsSections() {
		ArrayList<String> taList = new ArrayList<String>();
		Node curr = head;
		
		while(curr != null) {
			if(curr.section instanceof HonorSection) {
				taList.add(((HonorSection)curr.section).getTAName());
			}
			curr = curr.next;
		}
		
		return taList;
	}

	public Course removeSection(int sectionNumber) {
		Node curr = head, prev = null;
		
		while(curr != null) {
			if(curr.section.getSectionNumber() == sectionNumber) {
				HashSet<String> students = (HashSet<String>)curr.section.getStudents(false);
				if (curr == head) {
					head = head.next;
					
				}else {
					prev.next = curr.next;
				}
				if(curr.next != null) {
					for(String student: students) {
						curr.next.section.add(student);
					}
				}
				
			}
			prev = curr;
			curr = curr.next;
		}
		return this;
	}

	/* Provided: do not modify */
	public String toString() {
		return toString(head);
	}

	/* Provided: do not modify */
	private String toString(Node headAux) {
		if (headAux != null) {
			return headAux.section + "\n" + toString(headAux.next);
		}
		return "";
	}
}

package implementation;

/* Provided: do not modify */
public interface Task<K,V> {
	public void processing(K key, V data);
}

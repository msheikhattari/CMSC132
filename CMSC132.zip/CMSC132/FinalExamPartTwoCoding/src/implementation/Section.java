package implementation;

import java.util.*;

public class Section implements Comparable<Section>, Cloneable {
	private int sectionNumber;
	private HashSet<String> students;

	public Section(int sectionNumber) {
		this.sectionNumber = sectionNumber;
		students = new HashSet<String>();
	}

	public Section add(String newStudent) {
		students.add(newStudent);
		return this;
	}

	public int getSectionNumber() {
		return sectionNumber;
	}

	public int getEnrollment() {
		return students.size();
	}

	public Set<String> getStudents(boolean sorted) {
		if(sorted) {
			return new TreeSet<String>(students);
		}else {
			return students;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if(((Section)obj).sectionNumber == this.sectionNumber) {
			return true;
		}else {
			return false;
		}
	}

	public int hashCode() {
		return sectionNumber;
	}

	public int compareTo(Section section) {
		if(this.sectionNumber < section.sectionNumber) {
			return -1;
		}else if (this.sectionNumber > section.sectionNumber) {
			return 1;
		}else {
			return 0;
		}
	}

	@Override
	public Section clone() {
		Section copy = new Section(this.sectionNumber);
		for(String student: this.students) {
			copy.add(student);
		}
		
		return copy;
	}

	/* Provided: do not modify */
	public String toString() {
		return "Section Number: " + sectionNumber + "-" + getStudents(true);
	}
}

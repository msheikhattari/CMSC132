package implementation;

import java.util.*;

public class BinarySearchTree<K extends Comparable<K>, V> {
	private class Node {
		private K key;
		private V data;
		private Node left, right;

		public Node(K key, V data) {
			this.key = key;
			this.data = data;
		}
	}

	private Node root;

	public void processNodesTwoChildren(Task<K, V> task) {
		processNodesTwoChildrenAux(task, root);
	}
	
	private void processNodesTwoChildrenAux(Task<K, V> task, Node curr) {
		if(curr.left != null && curr.right != null) {
			task.processing(curr.key, curr.data);
			processNodesTwoChildrenAux(task, curr.left);
			processNodesTwoChildrenAux(task, curr.right);
		}else if(curr.left != null) {
			processNodesTwoChildrenAux(task, curr.left);
		}else if(curr.right != null) {
			processNodesTwoChildrenAux(task, curr.right);
		}
		
	}

	public ArrayList<K> getPathKeysToFind(K target) {
		ArrayList<K> path= new ArrayList<K>();
		return getPathKeysToFindAux(target, root, path);
	}
	
	private ArrayList<K> getPathKeysToFindAux(K target, Node curr, ArrayList<K> path) {
		int comparison = target.compareTo(curr.key);
		path.add(curr.key);
		
		if (comparison == 0) { // overwriting
			return path;
		} else if (comparison < 0) {
			if (curr.left == null) {
				return path;
			} else {
				return getPathKeysToFindAux(target, curr.left, path);
			}
		} else {
			if (curr.right == null) {
				return path;
			} else {
				return getPathKeysToFindAux(target, curr.right, path);
			}
		}
	}
	

	public Set<K> getKeysNodesLevel(int targetLevel) {
		 HashSet<K> nodes = new HashSet<K>();
		 getKeysNodesLevelAux(targetLevel, 1, nodes, root);
		 return nodes;
	}

	private void getKeysNodesLevelAux(int targetLevel, int currLevel, HashSet<K> nodes, Node curr) {
		if(currLevel == targetLevel) {
			nodes.add(curr.key);
		}else {
			if(curr.left != null){
				getKeysNodesLevelAux(targetLevel, currLevel + 1, nodes, curr.left);
			}
			if(curr.right != null) {
				getKeysNodesLevelAux(targetLevel, currLevel + 1, nodes, curr.right);
			}
		}
	}

	/* Support methods */
	/* Provided: do not modify */
	public boolean add(K key, V data) {
		if (root == null) {
			root = new Node(key, data);
			return true;
		} else {
			return addAux(key, data, root);
		}
	}

	private boolean addAux(K key, V data, Node rootAux) {
		int comparison = key.compareTo(rootAux.key);

		if (comparison == 0) { // overwriting
			rootAux.data = data;
			return false;
		} else if (comparison < 0) {
			if (rootAux.left == null) {
				rootAux.left = new Node(key, data);
				return true;
			} else {
				return addAux(key, data, rootAux.left);
			}
		} else {
			if (rootAux.right == null) {
				rootAux.right = new Node(key, data);
				return true;
			} else {
				return addAux(key, data, rootAux.right);
			}
		}
	}

	/* Provided: do not modify */
	public String toString() {
		return toStringAux(root, 0);
	}

	/* Provided: do not modify */
	private String toStringAux(Node rootAux, int indentation) {
		if (rootAux == null) {
			return "";
		} else {
			int indentationDelta = 4;
			String right = toStringAux(rootAux.right, indentation + indentationDelta) + "\n";
			right += " ".repeat(indentation);
			String elem = "{" + rootAux.key + ":" + rootAux.data + "}";
			String left = toStringAux(rootAux.left, indentation + indentationDelta);
			right += " ".repeat(indentation);
			return  right + elem + left;
		}
	}
}

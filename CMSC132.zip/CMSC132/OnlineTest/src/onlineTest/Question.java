package onlineTest;

import java.io.*;

public class Question implements Serializable {
	private static final long serialVersionUID = 1L;
	public int questionNumber;
	public String text;
	public double points;

	public Question(int questionNumber, String text, double points) {
		this.questionNumber = questionNumber;
		this.text = text;
		this.points = points;
	}
}

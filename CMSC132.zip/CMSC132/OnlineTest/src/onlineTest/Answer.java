package onlineTest;

import java.io.*;

public class Answer implements Serializable {
	private static final long serialVersionUID = 1L;

	public double score;
	public int examID;

	public Answer(double score, int examID) {
		this.score = score;
		this.examID = examID;
	}

}

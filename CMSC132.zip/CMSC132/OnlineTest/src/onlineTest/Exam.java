package onlineTest;

import java.util.ArrayList;
import java.io.*;

public class Exam implements Serializable {
	private static final long serialVersionUID = 1L;
	public int examID;
	public String title;
	public double totalPointsPossible = 0;

	public ArrayList<Question> questions = new ArrayList<Question>();

	public Exam(int examID, String title) {
		this.examID = examID;
		this.title = title;
	}

}

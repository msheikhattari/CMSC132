package onlineTest;

public class FIBQuestion extends Question {
	public String[] answer;

	public FIBQuestion(int questionNumber, String text, double points, String[] answer) {
		super(questionNumber, text, points);
		this.answer = answer;

	}

}

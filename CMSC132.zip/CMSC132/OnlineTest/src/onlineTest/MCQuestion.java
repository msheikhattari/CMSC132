package onlineTest;

public class MCQuestion extends Question {
	public String[] answer;

	public MCQuestion(int questionNumber, String text, double points, String[] answer) {
		super(questionNumber, text, points);
		this.answer = answer;

	}

}

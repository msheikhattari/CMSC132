package onlineTest;

public class TFQuestion extends Question {
	public boolean answer;

	public TFQuestion(int questionNumber, String text, double points, boolean answer) {
		super(questionNumber, text, points);
		this.answer = answer;

	}

}

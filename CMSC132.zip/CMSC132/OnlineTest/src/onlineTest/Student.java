package onlineTest;

import java.util.ArrayList;
import java.io.*;

public class Student implements Comparable<Student>, Serializable {
	private static final long serialVersionUID = 1L;

	public String studentName;
	public ArrayList<Answer> results = new ArrayList<Answer>();
	public ArrayList<Integer> uniqueExamIDs = new ArrayList<Integer>();

	public Student(String studentName) {
		this.studentName = studentName;
	}

	public int compareTo(Student student) {
		if (this.studentName.compareTo(student.studentName) < 0) {
			return -1;
		} else if (this.studentName.compareTo(student.studentName) > 0) {
			return 1;
		} else {
			return 0;
		}

	}

}

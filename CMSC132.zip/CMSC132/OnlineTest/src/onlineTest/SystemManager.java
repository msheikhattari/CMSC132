package onlineTest;

import java.io.*;
import java.util.*;

public class SystemManager implements Manager, Serializable {
	private static final long serialVersionUID = 1L;
	public ArrayList<Exam> exams = new ArrayList<Exam>();
	public ArrayList<Student> students = new ArrayList<Student>();
	String[] letterGrades;
	double[] cutoffs;

	@Override
	public boolean addExam(int examId, String title) {
		for (int i = 0; i < exams.size(); i++) {
			if (exams.get(i).examID == examId) {
				return false;
			}
		}
		exams.add(new Exam(examId, title));
		return true;
	}

	@Override
	public void addTrueFalseQuestion(int examId, int questionNumber, String text, 
			double points, boolean answer) {
		for (int i = 0; i < exams.size(); i++) {
			if (exams.get(i).examID == examId) {

				for (int j = 0; j < exams.get(i).questions.size(); j++) {
					if (exams.get(i).questions.get(j).questionNumber == questionNumber) {
						exams.get(i).questions.get(j).text = text;
						exams.get(i).questions.get(j).points = points;
						((TFQuestion) exams.get(i).questions.get(j)).answer = answer;
					}
				}

				exams.get(i).questions.add(new TFQuestion(questionNumber, text, 
													      points, answer));
				exams.get(i).totalPointsPossible += points;

			}
		}

	}

	@Override
	public void addMultipleChoiceQuestion(int examId, int questionNumber, 
								String text, double points, String[] answer) {
		for (int i = 0; i < exams.size(); i++) {
			if (exams.get(i).examID == examId) {

				for (int j = 0; j < exams.get(i).questions.size(); j++) {
					if (exams.get(i).questions.get(j).questionNumber == questionNumber) {
						exams.get(i).questions.get(j).text = text;
						exams.get(i).questions.get(j).points = points;
						((MCQuestion) exams.get(i).questions.get(j)).answer = answer;
					}
				}

				exams.get(i).questions.add(new MCQuestion(questionNumber, text, 
															points, answer));
				exams.get(i).totalPointsPossible += points;

			}
		}

	}

	@Override
	public void addFillInTheBlanksQuestion(int examId, int questionNumber, 
										   String text, double points,
			String[] answer) {
		for (int i = 0; i < exams.size(); i++) {
			if (exams.get(i).examID == examId) {

				for (int j = 0; j < exams.get(i).questions.size(); j++) {
					if (exams.get(i).questions.get(j).questionNumber == questionNumber) {
						exams.get(i).questions.get(j).text = text;
						exams.get(i).questions.get(j).points = points;
						((FIBQuestion) exams.get(i).questions.get(j)).answer = answer;
					}
				}

				exams.get(i).questions.add(new FIBQuestion(questionNumber, text,
														   points, answer));
				exams.get(i).totalPointsPossible += points;

			}
		}

	}

	@Override
	public String getKey(int examId) {
		Exam exam = null;
		StringBuffer key = new StringBuffer();

		for (int i = 0; i < exams.size(); i++) {
			if (exams.get(i).examID == examId) {
				exam = exams.get(i);
			}
		}

		if (exam == null) {
			return "Exam not found";
		}

		for (int i = 0; i < exam.questions.size(); i++) {
			Question question = exam.questions.get(i);

			key.append("Question Text: " + question.text);
			key.append("\nPoints: " + question.points + "\nCorrect Answer: ");

			if (question instanceof TFQuestion) {
				if (((TFQuestion) question).answer == true) {
					key.append("True\n");
				} else {
					key.append("False\n");
				}
			} else if (question instanceof MCQuestion) {

				// Sorting could cause errors for other students. Check this later

				Arrays.sort(((MCQuestion) question).answer);
				key.append(Arrays.toString(((MCQuestion) question).answer) + "\n");
			} else {
				Arrays.sort(((FIBQuestion) question).answer);
				key.append(Arrays.toString(((FIBQuestion) question).answer) + "\n");
			}

		}

		return key.toString();
	}

	@Override
	public boolean addStudent(String name) {
		for (int i = 0; i < students.size(); i++) {
			if (students.get(i).studentName.equals(name)) {
				return false;
			}
		}
		students.add(new Student(name));
		return true;
	}

	@Override
	public void answerTrueFalseQuestion(String studentName, int examId, 
											int questionNumber, boolean answer) {
		Exam exam = null;
		Student student = null;
		Question question = null;

		for (int i = 0; i < exams.size(); i++) {
			if (exams.get(i).examID == examId) {
				exam = exams.get(i);

			}
		}

		for (int i = 0; i < students.size(); i++) {
			if (students.get(i).studentName.equals(studentName)) {
				student = students.get(i);
			}
		}

		for (int i = 0; i < exam.questions.size(); i++) {
			if (exam.questions.get(i).questionNumber == questionNumber) {
				question = exam.questions.get(i);
			}
		}

		if (student.results.size() == 0) {
			student.uniqueExamIDs.add(examId);
		}

		if (((TFQuestion) question).answer == answer) {
			student.results.add(new Answer(question.points, examId));
		} else {
			student.results.add(new Answer(0.0, examId));
		}

		if (student.results.size() > 1) {
			if (student.results.get(student.results.size() - 2).examID != examId) {
				student.uniqueExamIDs.add(examId);
			}
		}

	}

	@Override
	public void answerMultipleChoiceQuestion(String studentName, int examId, 
										int questionNumber, String[] answer) {
		Exam exam = null;
		Student student = null;
		Question question = null;

		for (int i = 0; i < exams.size(); i++) {
			if (exams.get(i).examID == examId) {
				exam = exams.get(i);

			}
		}

		for (int i = 0; i < students.size(); i++) {
			if (students.get(i).studentName.equals(studentName)) {
				student = students.get(i);
			}
		}

		for (int i = 0; i < exam.questions.size(); i++) {
			if (exam.questions.get(i).questionNumber == questionNumber) {
				question = exam.questions.get(i);
			}
		}

		if (student.results.size() == 0) {
			student.uniqueExamIDs.add(examId);
		}

		if (Arrays.equals(((MCQuestion) question).answer, answer)) {
			student.results.add(new Answer(question.points, examId));
		} else {
			student.results.add(new Answer(0.0, examId));
		}

		if (student.results.size() > 1) {
			if (student.results.get(student.results.size() - 2).examID != examId) {
				student.uniqueExamIDs.add(examId);
			}
		}

	}

	@Override
	public void answerFillInTheBlanksQuestion(String studentName, int examId, 
										int questionNumber, String[] answer) {
		Exam exam = null;
		Student student = null;
		Question question = null;
		double score = 0;

		for (int i = 0; i < exams.size(); i++) {
			if (exams.get(i).examID == examId) {
				exam = exams.get(i);

			}
		}

		for (int i = 0; i < students.size(); i++) {
			if (students.get(i).studentName.equals(studentName)) {
				student = students.get(i);
			}
		}

		for (int i = 0; i < exam.questions.size(); i++) {
			if (exam.questions.get(i).questionNumber == questionNumber) {
				question = exam.questions.get(i);
			}
		}

		for (int i = 0; i < answer.length; i++) {
			for (int j = 0; j < ((FIBQuestion) question).answer.length; j++) {
				if (((FIBQuestion) question).answer[j].equals(answer[i])) {
					score += question.points / ((FIBQuestion) question).answer.length;
				}
			}
		}

		if (student.results.size() == 0) {
			student.uniqueExamIDs.add(examId);
		}

		student.results.add(new Answer(score, examId));

		if (student.results.size() > 1) {
			if (student.results.get(student.results.size() - 2).examID != examId) {
				student.uniqueExamIDs.add(examId);
			}
		}
	}

	@Override
	public double getExamScore(String studentName, int examId) {
		Student student = null;
		Exam exam = null;
		double score = 0;

		for (int i = 0; i < exams.size(); i++) {
			if (exams.get(i).examID == examId) {
				exam = exams.get(i);

			}
		}

		for (int i = 0; i < students.size(); i++) {
			if (students.get(i).studentName.equals(studentName)) {
				student = students.get(i);
			}
		}

		for (int i = 0; i < student.results.size(); i++) {
			if (student.results.get(i).examID == examId) {
				score += student.results.get(i).score;
			}
		}

		return score;
	}

	@Override
	public String getGradingReport(String studentName, int examId) {
		Student student = null;
		Exam exam = null;
		StringBuffer report = new StringBuffer();
		int j = 0;

		for (int i = 0; i < exams.size(); i++) {
			if (exams.get(i).examID == examId) {
				exam = exams.get(i);

			}
		}

		for (int i = 0; i < students.size(); i++) {
			if (students.get(i).studentName.equals(studentName)) {
				student = students.get(i);
			}
		}

		for (int i = 0; i < student.results.size(); i++) {
			if (student.results.get(i).examID == examId) {
				if (report.toString().split("[\n|\r]").length < i) {
					report.append("Question #" + (j + 1) + " " + student.results.get(i).score);
					report.append(" points out of " + exam.questions.get(j).points + "\n");
					j++;
				} else {
					report.append("Question #" + (i + 1) + " " + student.results.get(i).score);
					report.append(" points out of " + exam.questions.get(i).points + "\n");
				}

			}
		}

		report.append("Final Score: " + getExamScore(studentName, examId) + 
					  " out of " + exam.totalPointsPossible);

		return report.toString();
	}

	@Override
	public void setLetterGradesCutoffs(String[] letterGrades, double[] cutoffs) {
		this.letterGrades = letterGrades;
		this.cutoffs = cutoffs;
	}

	@Override
	public double getCourseNumericGrade(String studentName) {
		Student student = null;
		double scoreCounter = 0;

		for (int i = 0; i < students.size(); i++) {
			if (students.get(i).studentName.equals(studentName)) {
				student = students.get(i);
			}
		}

		for (int i = 0; i < student.uniqueExamIDs.size(); i++) {
			scoreCounter += getExamScore(studentName, student.uniqueExamIDs.get(i)) 
						  / exams.get(i).totalPointsPossible;
		}

		return (scoreCounter * 100) / student.uniqueExamIDs.size();
	}

	@Override
	public String getCourseLetterGrade(String studentName) {
		Student student = null;
		double numeric;

		for (int i = 0; i < students.size(); i++) {
			if (students.get(i).studentName.equals(studentName)) {
				student = students.get(i);
			}
		}

		numeric = getCourseNumericGrade(studentName);

		for (int i = 0; i < cutoffs.length; i++) {
			if (numeric >= cutoffs[i]) {
				return letterGrades[i];
			}
		}

		return null;
	}

	@Override
	public String getCourseGrades() {
		Collections.sort(students);
		StringBuffer grades = new StringBuffer();

		for (int i = 0; i < students.size(); i++) {
			grades.append(students.get(i).studentName + " " 
					+ getCourseNumericGrade(students.get(i).studentName) + " "
					+ getCourseLetterGrade(students.get(i).studentName));
		}
		return grades.toString();
	}

	@Override
	public double getMaxScore(int examId) {
		ArrayList<Double> scores = new ArrayList<Double>();

		for (int i = 0; i < students.size(); i++) {
			scores.add(getExamScore(students.get(i).studentName, examId));
		}

		Collections.sort(scores);

		return scores.get(scores.size() - 1);
	}

	@Override
	public double getMinScore(int examId) {
		ArrayList<Double> scores = new ArrayList<Double>();

		for (int i = 0; i < students.size(); i++) {
			scores.add(getExamScore(students.get(i).studentName, examId));
		}

		Collections.sort(scores);

		return scores.get(0);
	}

	@Override
	public double getAverageScore(int examId) {
		ArrayList<Double> scores = new ArrayList<Double>();
		double average = 0;

		for (int i = 0; i < students.size(); i++) {
			scores.add(getExamScore(students.get(i).studentName, examId));
		}

		Collections.sort(scores);

		for (int i = 0; i < scores.size(); i++) {
			average += scores.get(i);
		}

		average /= scores.size();

		return average;
	}

	@Override
	public void saveManager(Manager manager, String fileName) {

		try {

			File file = new File(fileName);
			ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(file));

			output.writeObject(manager);
			output.close();
		} catch (IOException i) {
			i.printStackTrace();
		}

	}

	@Override
	public Manager restoreManager(String fileName) {
		File file = new File(fileName);

		if (!file.exists()) {
			return new SystemManager();
		} else {
			try {
				ObjectInputStream input = new ObjectInputStream(new FileInputStream(file));
				try {
					Manager manager = (Manager) input.readObject();
					input.close();
					return manager;
				} catch (ClassNotFoundException j) {
					input.close();
					return new SystemManager();
				}
			} catch (IOException e) {
				return new SystemManager();
			}
		}
	}

}

package tests;
import java.util.*;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import implementation.*;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class StudentTests {
    @Test
    public void graphTest1() {
            Graph graph = new Graph<Integer>();
            int d1 = 7, d2 = 8, d3 = 10, d4 = 40;
            
            
            graph.addVertex("A", d1);
            graph.addVertex("B", d2);
            graph.addVertex("C", d3);
            
            graph.addDirectedEdge("A", "B", 2);
            graph.addDirectedEdge("B", "C", 3);
            graph.addDirectedEdge("C", "A", 1);
            graph.addDirectedEdge("A", "C", d4);
            
            Map<String, Integer> aVertices = graph.getAdjacentVertices("A");
            int abCost = graph.getCost("A", "B");
            Set<String> set = graph.getVertices();
            int aData = (int)graph.getData("A");
            int cData = (int)graph.getData("C");
    }
}
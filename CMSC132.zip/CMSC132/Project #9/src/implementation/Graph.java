package implementation;

import java.util.*;

/**
 * Implements a graph. We use two maps: one map for adjacency properties
 * (adjancencyMap) and one map (dataMap) to keep track of the data associated
 * with a vertex.
 * 
 * @author cmsc132
 * 
 * @param <E>
 */
public class Graph<E> {
	/* You must use the following maps in your implementation */
	private HashMap<String, HashMap<String, Integer>> adjacencyMap;
	private HashMap<String, E> dataMap;

	public Graph() {
		adjacencyMap = new HashMap<String, HashMap<String, Integer>>();
		dataMap = new HashMap<String, E>();
	}

	public void addVertex(String vertexName, E data) {
		if (adjacencyMap.containsKey(vertexName) || dataMap.containsKey(vertexName)) {
			throw new IllegalArgumentException("STOP");
		}
		adjacencyMap.put(vertexName, new HashMap<String, Integer>());
		dataMap.put(vertexName, data);
	}

	public void addDirectedEdge(String startVertexName, String endVertexName, int cost) {
		if (!(adjacencyMap.containsKey(startVertexName) && dataMap.containsKey(startVertexName))
				|| !(adjacencyMap.containsKey(endVertexName) && dataMap.containsKey(endVertexName))) {
			throw new IllegalArgumentException("STOP");
		}

		adjacencyMap.get(startVertexName).put(endVertexName, cost);
	}

	public String toString() {
		Map<String, Map<String, Integer>> sortedMap = new TreeMap<>(adjacencyMap);
		Map<String, Integer> subSortedMap;
		StringBuffer sb = new StringBuffer(), sb2 = new StringBuffer("Edges:\n");
		sb.append("Vertices: [");

		for (Map.Entry<String, Map<String, Integer>> entry : sortedMap.entrySet()) {
			subSortedMap = new TreeMap<>(entry.getValue());
			sb.append(entry.getKey() + ", ");
			sb2.append("Vertex(" + entry.getKey() + ")--->{");
			for (Map.Entry<String, Integer> entry2 : subSortedMap.entrySet()) {
				sb2.append(entry2.getKey() + "=" + entry2.getValue() + ", ");
			}
			if (!subSortedMap.isEmpty()) {
				sb2.deleteCharAt(sb2.length() - 1);
				sb2.deleteCharAt(sb2.length() - 1);
			}
			sb2.append("}\n");
		}
		sb.deleteCharAt(sb.length() - 1);
		sb.deleteCharAt(sb.length() - 1);
		sb.append("]\n");
		sb.append(sb2);

		return sb.toString();

	}

	public Map<String, Integer> getAdjacentVertices(String vertexName) {
		Map<String, Integer> sortedMap = new TreeMap<>(adjacencyMap.get(vertexName));

		return sortedMap;
	}

	public int getCost(String startVertexName, String endVertexName) {
		Map<String, Integer> sortedMap = new TreeMap<>(adjacencyMap.get(startVertexName));

		for (Map.Entry<String, Integer> entry : sortedMap.entrySet()) {
			if (entry.getKey().equals(endVertexName)) {
				return entry.getValue();
			}
		}
		return 0;

	}
	
	public Set<String> getVertices(){
		Map<String, E> sortedMap = new TreeMap<>(dataMap);
		Set<String> set = new TreeSet<String>();
		
		for (Map.Entry<String, E> entry : sortedMap.entrySet()) {
			set.add(entry.getKey());
		}
		
		return set;
	}
	
	public E getData(String vertex) {
		if (!(adjacencyMap.containsKey(vertex) && dataMap.containsKey(vertex))) {
			throw new IllegalArgumentException("STOP");
		}
		
		return dataMap.get(vertex);
		
	}

	public void doDepthFirstSearch(String startVertexName, CallBack<E> callback) {
		if (!(adjacencyMap.containsKey(startVertexName) && dataMap.containsKey(startVertexName))) {
			throw new IllegalArgumentException("STOP");
		}

		TreeSet visited = new TreeSet<String>();
		Stack discovered = new Stack<String>();
		String temp;
		discovered.add(startVertexName);

		while (!(discovered.isEmpty())) {
			temp = (String) discovered.firstElement();
			discovered.remove(temp);
			if (!(visited.contains(temp))) {
				visited.add(temp);
				callback.processVertex(temp, dataMap.get(temp));
				Map<String, Integer> sortedMap = new TreeMap<String, Integer>(adjacencyMap.get(temp));
				for (Map.Entry<String, Integer> entry : sortedMap.entrySet()) {
					if (!(visited.contains(entry.getKey()))) {
						discovered.add(0, entry.getKey());
					}
				}
			}
		}
	}

	public void doBreadthFirstSearch(String startVertexName, CallBack<E> callback) {
		if (!(adjacencyMap.containsKey(startVertexName) && dataMap.containsKey(startVertexName))) {
			throw new IllegalArgumentException("STOP");
		}

		TreeSet visited = new TreeSet<String>();
		Stack discovered = new Stack<String>();
		String temp;
		discovered.add(startVertexName);

		while (!(discovered.isEmpty())) {
			temp = (String) discovered.firstElement();
			discovered.remove(temp);
			if (!(visited.contains(temp))) {
				visited.add(temp);
				callback.processVertex(temp, dataMap.get(temp));
				Map<String, Integer> sortedMap = new TreeMap<String, Integer>(adjacencyMap.get(temp));
				for (Map.Entry<String, Integer> entry : sortedMap.entrySet()) {
					if (!(visited.contains(entry.getKey()))) {
						discovered.add(entry.getKey());
					}
				}
			}
		}
	}

	public int doDijkstras(String startVertexName, String endVertexName, ArrayList<String> shortestPath) {
		if (!(adjacencyMap.containsKey(startVertexName) && dataMap.containsKey(startVertexName))
				|| !(adjacencyMap.containsKey(endVertexName) && dataMap.containsKey(endVertexName))) {
			throw new IllegalArgumentException("STOP");
		}
		ArrayList s = new ArrayList<String>();
		HashMap p = new HashMap<String, String>();
		HashMap c = new HashMap<String, Integer>();
		String tempName = "";
		Set<String> allVertices = this.getVertices();
		Iterator iterator = allVertices.iterator();
		int noPre = 0;
		
		

		
		
		
		while(iterator.hasNext()) {
			String name = (String)iterator.next();
			c.put(name, Integer.MAX_VALUE);
			p.put(name, "");
		}
		
		c.remove(startVertexName);
		c.put(startVertexName, 0);

		

		while (s.size() < dataMap.size()) {
			int tempCost = Integer.MAX_VALUE;
			Map<String, Integer> sortedC = new HashMap<String, Integer>(c);
			for (Map.Entry<String, Integer> entry : sortedC.entrySet()) {
				if (entry.getValue() < tempCost) {
					if (!(s.contains(entry.getKey()))) {
						tempName = entry.getKey();
						tempCost = entry.getValue();
					}
				}
			}
			
			if(!s.contains(tempName)) {
				s.add(tempName);
			}else {
				Map<String, String> sortedP = new HashMap<String, String>(p);
				
				for(Map.Entry<String, String> entry : sortedP.entrySet()) {
					if(entry.getValue().isEmpty() && !(entry.getKey().equals(startVertexName))) {
						s.add(entry.getKey());
					}
				}
			}
			
			
			Map<String, Integer> sortedMap = new TreeMap<>(adjacencyMap.get(tempName));
			
			for (Map.Entry<String, Integer> entry : sortedMap.entrySet()) {
				if(!(s.contains(entry.getKey()))) {
					int newCost = (int)c.get(tempName) + getCost(tempName, entry.getKey());
					if((int)c.get(entry.getKey()) > newCost) {
						c.remove(entry.getKey());
						c.put(entry.getKey(), newCost);	
						
						p.remove(entry.getKey());
						p.put(entry.getKey(), tempName);
						
					}
				}
			}

		}
		if(p.get(endVertexName).equals("") && !endVertexName.equals(startVertexName)) {
			
		}else {
			shortestPath.add(endVertexName);
			shortestPath.add(0, (String)p.get(endVertexName));
		}
		
		String predecessor = (String)p.get(endVertexName);
		
		
		while(!(predecessor.isEmpty())) {
			predecessor = (String)p.get(predecessor);
			shortestPath.add(0, predecessor);
		}
		if(shortestPath.size() > 0) {
			shortestPath.remove(0);
		}
		
		if((int)c.get(endVertexName) == Integer.MAX_VALUE) {
			shortestPath.add("None");
			return -1;
		}
		
		return (int)c.get(endVertexName);
		
		
		
	}

}
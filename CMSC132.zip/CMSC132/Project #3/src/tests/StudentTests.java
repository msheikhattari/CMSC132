package tests;

import static org.junit.Assert.*;

import java.util.Random;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import model.BoardCell;
import model.ClearCellGame;
import model.Game;

/* The following directive executes tests in sorted order */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class StudentTests {
	
	/* Remove the following test and add your tests */
	@Test
	public void gameGettersTest() {
		Game game = new ClearCellGame(4, 4, new Random(1L), 1);
	
		assertTrue(game.getMaxCols() == 4 && game.getMaxRows() == 4);
	}
	@Test
	public void gameGetSetBoardCellTest() {
		Game game = new ClearCellGame(4, 4, new Random(1L), 1);
		
		game.setBoardCell(2, 2, BoardCell.RED);
		game.getBoardCell(2, 2);
		
		assertTrue(game.getBoardCell(2,2) == BoardCell.RED);
	}
	@Test
	public void gameSetRowWithColorTest() {
		Game game = new ClearCellGame(4, 4, new Random(1L), 1);
		
		game.setRowWithColor(2, BoardCell.RED);
		
		assertTrue(game.getBoardCell(2,2) == BoardCell.RED);
	}
	@Test
	public void gameSetColWithColorTest() {
		Game game = new ClearCellGame(4, 4, new Random(1L), 1);
		
		game.setColWithColor(2, BoardCell.RED);
		
		assertTrue(game.getBoardCell(2,2) == BoardCell.RED);
	}
	@Test
	public void gameSetBoardWithColorTest() {
		Game game = new ClearCellGame(4, 4, new Random(1L), 1);
		
		game.setBoardWithColor(BoardCell.RED);
		
		assertTrue(game.getBoardCell(2,2) == BoardCell.RED);
	}
	@Test
	public void clearCellIsGameOverTest() {
		Game game = new ClearCellGame(4, 4, new Random(1L), 1);
		
		game.setColWithColor(2, BoardCell.RED);
		
		assertTrue(game.isGameOver());
	}
	@Test
	public void clearCellNextAnimationStepTest() {
		Game game = new ClearCellGame(4, 4, new Random(1L), 1);
		
		game.nextAnimationStep();
		
		assertTrue(game.getBoardCell(0,0).getColor() != BoardCell.EMPTY.getColor());
	}
	@Test
	public void clearCellMultipleNextAnimationStepTest() {
		Game game = new ClearCellGame(4, 4, new Random(1L), 1);
		
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();
		
		assertTrue(game.getBoardCell(2,0).getColor() != BoardCell.EMPTY.getColor());
	}
	@Test
	public void clearCellTooManyNextAnimationStepTest() {
		Game game = new ClearCellGame(4, 4, new Random(1L), 1);
		
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();

		
		assertTrue(game.getBoardCell(3,0).getColor() != BoardCell.EMPTY.getColor());
	}
	@Test
	public void clearCellGetScoreProcessCellTest() {
		Game game = new ClearCellGame(5, 4, new Random(1L), 1);
		
		game.setRowWithColor(0, BoardCell.RED);
		game.processCell(0, 0);

		
		assertTrue(game.getScore() == 4);
	}
	@Test
	public void clearCellProcessCellMultipleClearingWithObstacleTest() {
		Game game = new ClearCellGame(5, 4, new Random(1L), 1);
		
		game.setRowWithColor(0, BoardCell.RED);
		game.setRowWithColor(1, BoardCell.RED);
		game.setRowWithColor(2, BoardCell.BLUE);
		game.setRowWithColor(3, BoardCell.RED);
		game.processCell(0, 0);
		System.out.println(game.getScore());

		
		assertTrue(game.getScore() == 6);
	}
	@Test
	public void clearCellProcessCellGameOverTest() {
		Game game = new ClearCellGame(4, 4, new Random(1L), 1);
		
		game.setRowWithColor(0, BoardCell.RED);
		game.setRowWithColor(1, BoardCell.RED);
		game.setRowWithColor(2, BoardCell.BLUE);
		game.setRowWithColor(3, BoardCell.RED);
		game.processCell(0, 0);
		System.out.println(game.getScore());

		
		assertTrue(game.getScore() == 0);
	}
	@Test
	public void clearCellProcessCellDirectionsCheckTest() {
		Game game = new ClearCellGame(10, 10, new Random(1L), 1);
		
		game.setBoardWithColor(BoardCell.RED);
		game.setRowWithColor(9, BoardCell.EMPTY);
		game.processCell(0, 0);
		System.out.println(game.getScore());

		
		assertTrue(game.getScore() == 26);
	}
	
	@Test
	public void clearCellProcessCellMultipleCollapseTest() {
		Game game = new ClearCellGame(6, 2, new Random(1L), 1);
		
		game.setBoardWithColor(BoardCell.RED);
		game.setRowWithColor(2, BoardCell.BLUE);
		game.setRowWithColor(3, BoardCell.GREEN);
		game.setRowWithColor(4, BoardCell.YELLOW);
		game.setRowWithColor(5, BoardCell.EMPTY);
		game.processCell(0, 0);
		System.out.println(game.getScore());

		
		assertTrue(game.getScore() == 4);
	}
	
	
	@Test
	public void clearCellNextAnimationStepTooManyRowsTest() {
		Game game = new ClearCellGame(8, 2, new Random(1L), 1);
		
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();
		
		
		System.out.println(game.getBoardCell(7, 1));

		
		assertTrue(game.getBoardCell(7, 1) != BoardCell.EMPTY);
	}
	
	@Test
	public void clearCellNextAnimationStepWithProessCellTest() {
		Game game = new ClearCellGame(8, 6, new Random(1L), 1);
		
		game.nextAnimationStep();
		game.processCell(0, 0);
		
		
		System.out.println(game.getBoardCell(7, 1));

		
		assertTrue(game.getBoardCell(0, 5) != BoardCell.EMPTY);
	}
	
}

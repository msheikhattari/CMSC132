package model;

import java.util.Random;

/**
 * This class extends GameModel and implements the logic of the clear cell game.
 * We define an empty cell as BoardCell.EMPTY. An empty row is defined as one
 * where every cell corresponds to BoardCell.EMPTY.
 * 
 * @author Department of Computer Science, UMCP
 */

public class ClearCellGame extends Game {
	Random random;
	int strategy;
	int score = 0;
	static int earliestEmptyRow = 0;

	/**
	 * Defines a board with empty cells. It relies on the super class constructor to
	 * define the board. The random parameter is used for the generation of random
	 * cells. The strategy parameter defines which clearing cell strategy to use
	 * (for this project it will be 1). For fun, you can add your own strategy by
	 * using a value different that one.
	 * 
	 * @param maxRows
	 * @param maxCols
	 * @param random
	 * @param strategy
	 */
	public ClearCellGame(int maxRows, int maxCols, Random random, int strategy) {
		super(maxRows, maxCols);
		this.random = random;
		this.strategy = strategy;
	}

	/**
	 * The game is over when the last board row (row with index board.length -1) is
	 * different from empty row.
	 */
	public boolean isGameOver() {
		for (int i = 0; i < maxCols; i++) {
			if (board[maxRows - 1][i] != BoardCell.EMPTY) {
				return true;
			}
		}
		return false;
	}

	public int getScore() {
		return score;
	}

	/**
	 * This method will attempt to insert a row of random BoardCell objects if the
	 * last board row (row with index board.length -1) corresponds to the empty row;
	 * otherwise no operation will take place.
	 */
	public void nextAnimationStep() {
		int j = 0;
		earliestEmptyRow++;

		for (int i = 0; i < maxCols; i++) {
			if (board[maxRows - 1][i] != BoardCell.EMPTY) {
				return;
			}
		} // Checks if there's anything in the last row
		
		if(maxRows == 1) {
			for (int i = 0; i < maxCols; i++) {
				board[0][i] = BoardCell.getNonEmptyRandomBoardCell(random);
			}
			return;
		}

		for(int w = 0; w < maxRows; w++) {
			for (int i = 0; i < maxCols; i++) {
				if (board[w][i] != BoardCell.EMPTY) {
					j++;
					i = maxCols;
				}	
			} // Finds nearest empty row
		}
		if (j > 1) {// Moves all the rows down 1
			for (int k = j; k > 0; k--) {
				for (int i = 0; i < maxCols; i++) {
					board[k][i] = board[k - 1][i];
				}
			}
		} else {// Case where only 1 row in board
			for (int i = 0; i < maxCols; i++) {
				board[1][i] = board[0][i];
			}
		}

		for (int i = 0; i < maxCols; i++) {
			board[0][i] = BoardCell.EMPTY;
		} // Discards top row which has a duplicate below it.

		for (int i = 0; i < maxCols; i++) {
			board[0][i] = BoardCell.getNonEmptyRandomBoardCell(random);
		} // Creates new top row.
	}

	/**
	 * This method will turn to BoardCell.EMPTY the cell selected and any adjacent
	 * surrounding cells in the vertical, horizontal, and diagonal directions that
	 * have the same color. The clearing of adjacent cells will continue as long as
	 * cells have a color that corresponds to the selected cell. Notice that the
	 * clearing process does not clear every single cell that surrounds a cell
	 * selected (only those found in the vertical, horizontal or diagonal
	 * directions).
	 * 
	 * IMPORTANT: Clearing a cell adds one point to the game's score.<br />
	 * <br />
	 * 
	 * If after processing cells, any rows in the board are empty,those rows will
	 * collapse, moving non-empty rows upward. For example, if we have the following
	 * board (an * represents an empty cell):<br />
	 * <br />
	 * RRR<br />
	 * GGG<br />
	 * YYY<br />
	 * * * *<br/>
	 * <br />
	 * then processing each cell of the second row will generate the following
	 * board<br />
	 * <br />
	 * RRR<br />
	 * YYY<br />
	 * * * *<br/>
	 * * * *<br/>
	 * <br />
	 * IMPORTANT: If the game has ended no action will take place.
	 * 
	 * 
	 */
	public void processCell(int rowIndex, int colIndex) {
		if (this.maxRows <= rowIndex || this.maxCols <= colIndex) {
			throw new IllegalArgumentException("INVALID INDICE(S)");
		}

		if (this.board[rowIndex][colIndex].getColor() == BoardCell.EMPTY.getColor()) {
			return;
		}

		if (this.isGameOver()) {
			return;
		}
		
		int n = 0;

		for(int w = 0; w < maxRows; w++) {
			for (int i = 0; i < maxCols; i++) {
				if (board[w][i] != BoardCell.EMPTY) {
					n++;
					i = maxCols;
				}	
			} // Finds nearest empty row
		}
		
		earliestEmptyRow = n;
		
		score += wipeIteration(rowIndex, colIndex);
		this.board[rowIndex][colIndex] = BoardCell.EMPTY;

		int[] clearedRows = this.clearedRows();

		for (int i = 0; i < clearedRows.length; i++) {
			int row;
			int currentRow = board.length - 1;
			int counter = 0;

			if (clearedRows[i] == -1) {// Stops processing if no more empty rows
				return;
			} else {
				row = clearedRows[i];

				for (int k = row; k < this.lastNonEmptyRow(); k++) {
					for (int l = 0; l < maxCols; l++) {
						board[k][l] = board[k + 1][l];// Shifts all rows up
					}
				}

				while (counter == 0) {// IDs nearest nonempty row from bottom
					for (int k = 0; k < maxCols; k++) {
						if (board[currentRow][k].getColor() != BoardCell.EMPTY.getColor()) {
							counter++;
						}
					}
					if (counter == 0 && currentRow!= 0) {
						currentRow--;
					} else {
						break;
					}
				}

				for (int j = 0; j < maxCols; j++) {
					board[currentRow][j] = BoardCell.EMPTY;
				}

				for (int j = i + 1; j < clearedRows.length; j++) {
					if (clearedRows[j] != -1) {
						clearedRows[j]--;// Corrects cleared rows indices after shifting
					}
				}

			}
		}

	}

	private boolean isWiped(int rowIndex, int colIndex, int baseRow, int baseCol) {
		if (rowIndex < this.maxRows && colIndex < this.maxCols && rowIndex >= 0 && colIndex >= 0
				&& this.board[baseRow][baseCol].getColor() == this.board[rowIndex][colIndex].getColor()) {
			return true;
		} else {
			return false;
		}
	}

	private int wipeIteration(int rowIndex, int colIndex) {
		int counter = 1;
		int scoreTracker = 1;
		BoardCell base = board[rowIndex][colIndex];

		while(isWiped(rowIndex + counter, colIndex, rowIndex, colIndex)) {
			board[rowIndex + counter][colIndex] = BoardCell.EMPTY;
			counter++;
			scoreTracker++;
		}
		counter = 1;
		
		while(isWiped(rowIndex - counter, colIndex, rowIndex, colIndex)) {
			board[rowIndex - counter][colIndex] = BoardCell.EMPTY;
			counter++;
			scoreTracker++;
		}
		counter = 1;
		
		while(isWiped(rowIndex, colIndex + counter, rowIndex, colIndex)) {
			board[rowIndex][colIndex + counter] = BoardCell.EMPTY;
			counter++;
			scoreTracker++;
		}
		counter = 1;
		
		while(isWiped(rowIndex, colIndex - counter, rowIndex, colIndex)) {
			board[rowIndex][colIndex - counter] = BoardCell.EMPTY;
			counter++;
			scoreTracker++;
		}
		counter = 1;
		
		while(isWiped(rowIndex + counter, colIndex + counter, rowIndex, colIndex)) {
			board[rowIndex + counter][colIndex + counter] = BoardCell.EMPTY;
			counter++;
			scoreTracker++;
		}
		counter = 1;
		
		while(isWiped(rowIndex - counter, colIndex + counter, rowIndex, colIndex)) {
				board[rowIndex - counter][colIndex + counter] = BoardCell.EMPTY;
				counter++;
				scoreTracker++;
			}
			counter = 1;
			
		while(isWiped(rowIndex + counter, colIndex - counter, rowIndex, colIndex)) {
				board[rowIndex + counter][colIndex - counter] = BoardCell.EMPTY;
				counter++;
				scoreTracker++;
			}
			counter = 1;
			
		while(isWiped(rowIndex - counter, colIndex - counter, rowIndex, colIndex)) {
				board[rowIndex - counter][colIndex - counter] = BoardCell.EMPTY;
				counter++;
				scoreTracker++;
			}
			counter = 1;
			
			return scoreTracker;
	}

	private int[] clearedRows() {
		int counter = 0;
		int[] clearedRows = new int[maxRows];// Stores rowIndex of cleared rows.

		for (int i = 0; i < clearedRows.length; i++) {
			clearedRows[i] = -1;
		} // This initializes clearedRows to allow easier ID of next empty index.

		for (int i = 0; i < maxRows; i++) {
			counter = 0;
			for (int j = 0; j < maxCols; j++) {
				if (board[i][j].getColor() != BoardCell.EMPTY.getColor()) {
					counter++;//Keeps skipping until empty row is reached
				}
			}
			if (counter == 0 && i < earliestEmptyRow) {
				int k = 0, l = 0;

				while (k == 0) {
					if (clearedRows[l] != -1) {
						l++;
					} else if(i == maxRows - 1){
						k++;
					}else {
						clearedRows[l] = i;
						k++;
					}
				}
			}
		}
		return clearedRows;
	}
	
	private int lastNonEmptyRow() {
		int counter = 0;
		
		for(int i = maxRows - 1; i > 0; i--) {
			for(int j = 0; j < maxCols; j++) {
				if(board[i][j].getColor() != BoardCell.EMPTY.getColor()) {
					counter++;
				}
			}
			if(counter != 0) {
				return i;
			}
		}
		return 0;
	}
}
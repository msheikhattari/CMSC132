package processor;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.*;

public class Person implements Runnable {
	int ID;
	ArrayList<Item> selfItems, masterItems;
	String orderFile;

	public void run() {
		try {
			System.out.println("Reading order for client with id: " + ID);
			Scanner userSC = new Scanner(new BufferedReader(new FileReader(orderFile)));
			userSC.next();
			userSC.next();

			while (userSC.hasNext()) {
				String currentItem = userSC.next();
				for (int i = 0; i < selfItems.size(); i++) {
					if (currentItem.equals(selfItems.get(i).name)) {
						selfItems.get(i).quantity++;
						selfItems.get(i).totalCost = selfItems.get(i).unitCost *
													 selfItems.get(i).quantity;
					}
				}
				userSC.next();

				synchronized (masterItems) {
					for (int i = 0; i < masterItems.size(); i++) {
						if (currentItem.equals(masterItems.get(i).name)) {
							masterItems.get(i).quantity++;
							masterItems.get(i).totalCost = masterItems.get(i).unitCost * 
									  					   masterItems.get(i).quantity;
						}
					}
				}

			}

		} catch (FileNotFoundException e) {

		}
	}

	Person(ArrayList<Item> masterItems, String orderFile) {
		this.masterItems = masterItems;
		this.orderFile = orderFile;
		selfItems = new ArrayList<Item>();

		for (int i = 0; i < masterItems.size(); i++) {
			selfItems.add(new Item(masterItems.get(i)));
		}

	}

	public void assignID() {
		try {
			Scanner userSC = new Scanner(new BufferedReader(new FileReader(orderFile)));
			userSC.next();

			this.ID = Integer.parseInt(userSC.next());

		} catch (FileNotFoundException e) {

		}
	}

	public void updateSelf(ArrayList<Item> masterItems) {
		try {
			Scanner userSC = new Scanner(new BufferedReader(new FileReader(orderFile)));
			userSC.next();
			userSC.next();

			while (userSC.hasNext()) {
				String currentItem = userSC.next();
				for (int i = 0; i < selfItems.size(); i++) {
					if (currentItem.equals(selfItems.get(i).name)) {
						selfItems.get(i).quantity++;
						selfItems.get(i).totalCost = selfItems.get(i).unitCost * 
								        			 selfItems.get(i).quantity;
					}
				}
				userSC.next();

				for (int i = 0; i < masterItems.size(); i++) {
					if (currentItem.equals(masterItems.get(i).name)) {
						masterItems.get(i).quantity++;
						masterItems.get(i).totalCost = masterItems.get(i).unitCost * 
								  					   masterItems.get(i).quantity;
					}
				}

			}

		} catch (FileNotFoundException e) {

		}
	}

}

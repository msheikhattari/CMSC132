package processor;

import java.util.*;
import java.io.*;

public class Item implements Comparable<Item> {
	public String name;
	public double unitCost;
	public int quantity = 0;
	public double totalCost = 0;

	Item(String name, double unitCost) {
		this.name = name;
		this.unitCost = unitCost;
	}

	Item(Item item) {
		this.name = new String(item.name);
		this.unitCost = item.unitCost;
	}

	public static ArrayList<Item> itemsList(String itemsDataFile) {
		ArrayList<Item> items = new ArrayList<Item>();

		try {
			Scanner itemSC = new Scanner(new BufferedReader(new FileReader(itemsDataFile)));

			while (itemSC.hasNext()) {
				String itemName = itemSC.next();
				double itemCost = Double.parseDouble(itemSC.next());

				items.add(new Item(itemName, itemCost));
			}

		} catch (FileNotFoundException e) {

		}

		return items;
	}

	public int compareTo(Item item) {
		if (this.name.compareTo(item.name) < 1) {
			return -1;
		} else if (this.name.compareTo(item.name) > 1) {
			return 1;
		} else {
			return 0;
		}
	}

}

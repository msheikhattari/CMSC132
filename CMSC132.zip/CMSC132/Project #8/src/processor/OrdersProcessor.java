package processor;

import java.util.*;
import java.io.*;
import java.text.*;
import java.lang.*;

public class OrdersProcessor {

	public static void main(String args[]) {
		String itemsDataFile, ordersBaseFile, resultsFile;
		boolean threading;
		int numberOrders;
		Scanner scanner = new Scanner(System.in);
		StringBuilder results = new StringBuilder();

		System.out.print("Enter item's data file name: ");
		itemsDataFile = scanner.next();

		System.out.print("Enter 'y' for multiple threads, any other character otherwise: ");
		if (scanner.next().equals("y")) {
			threading = true;
		} else {
			threading = false;
		}

		System.out.print("Enter number of orders to process: ");
		numberOrders = scanner.nextInt();

		System.out.print("Enter order's base filename: ");
		ordersBaseFile = scanner.next();

		System.out.print("Enter result's filename: ");
		resultsFile = scanner.next();
		scanner.close();

		long startTime = System.currentTimeMillis();

		ArrayList<Item> masterItems = Item.itemsList(itemsDataFile);
		Person[] people = new Person[numberOrders];
		Thread[] threads = new Thread[numberOrders];

		for (int i = 1; i <= numberOrders; i++) {
			String ordersFile = ordersBaseFile + i + ".txt";
			people[i - 1] = new Person(masterItems, ordersFile);
			people[i - 1].assignID();
			threads[i - 1] = new Thread(people[i - 1]);

			if (threading == false) {
				people[i - 1].updateSelf(masterItems);
				System.out.println("Reading order for client with id: " + people[i - 1].ID);
			}
		}

		if (threading) {
			for (int i = 0; i < numberOrders; i++) {
				threads[i].start();
			}

			for (int i = 0; i < numberOrders; i++) {
				try {
					threads[i].join();
				} catch (InterruptedException e) {

				}
			}

		}

		for (int i = 0; i < numberOrders; i++) {
			Collections.sort(people[i].selfItems);
			results.append("----- Order details for client with Id: " + people[i].ID);
			results.append(" -----\n");
			double selfTotal = 0;

			for (int j = 0; j < people[i].selfItems.size(); j++) {
				if (people[i].selfItems.get(j).quantity > 0) {
					results.append("Item's name: " + people[i].selfItems.get(j).name);
					results.append(", Cost per item: " + NumberFormat.getCurrencyInstance().
							       format(people[i].selfItems.get(j).unitCost));
					results.append(", Quantity: " + people[i].selfItems.get(j).quantity);
					results.append(", Cost: " + NumberFormat.getCurrencyInstance().
							       format(people[i].selfItems.get(j).totalCost));
					results.append("\n");

					selfTotal += people[i].selfItems.get(j).totalCost;
				}
			}
			results.append("Order Total: " + NumberFormat.getCurrencyInstance().
					       format(selfTotal) + "\n");
		}

		Collections.sort(masterItems);
		double masterTotal = 0;
		results.append("***** Summary of all orders *****\n");

		for (int i = 0; i < masterItems.size(); i++) {
			if (masterItems.get(i).quantity > 0) {
				results.append("Summary - Item's name: " + masterItems.get(i).name);
				results.append(", Cost per item: " + NumberFormat.getCurrencyInstance().
						format(masterItems.get(i).unitCost));
				results.append(", Number sold: " + masterItems.get(i).quantity);
				results.append(", Item's Total: " + NumberFormat.getCurrencyInstance().
						       format(masterItems.get(i).totalCost) + "\n");

				masterTotal += masterItems.get(i).totalCost;
			}
		}
		results.append("Summary Grand Total: " + NumberFormat.getCurrencyInstance().
				       format(masterTotal) + "\n");
		textUpload(results.toString(), resultsFile);

		long endTime = System.currentTimeMillis();
		System.out.println("Processing time (msec): " + (endTime - startTime));
		System.out.println("Results can be found in the file: " + resultsFile);
	}

	private static void textUpload(String text, String fileName) {
		try {
			BufferedWriter output = new BufferedWriter(new FileWriter(fileName));
			output.write(text);
			output.close();
		} catch (IOException e) {

		}
	}

}
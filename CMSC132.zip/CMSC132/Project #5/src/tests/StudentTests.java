package tests;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;

import org.junit.Test;

/**
 * 
 * You need student tests if you are looking for help during office hours about
 * bugs in your code.
 * 
 * @author UMCP CS Department
 *
 */
public class StudentTests {

	@Test
	public void basicAddFrontTest() {
		listClasses.BasicLinkedList<String> friendsList = new listClasses.BasicLinkedList();

		friendsList.addToFront("Apple").addToFront("Green").addToFront("Poop");

		System.out.println(friendsList.getSize());

		assertTrue(friendsList.getFirst().equals("Poop"));
	}

	@Test
	public void basicAddEndTest() {
		listClasses.BasicLinkedList<String> friendsList = new listClasses.BasicLinkedList();

		friendsList.addToEnd("Apple").addToEnd("Green").addToEnd("Poop");

		System.out.println(friendsList.getSize());
		assertTrue(friendsList.getFirst().equals("Apple"));
	}

	@Test
	public void getFirstLastTest() {
		listClasses.BasicLinkedList<String> friendsList = new listClasses.BasicLinkedList();

		friendsList.addToEnd("Apple").addToEnd("Green").addToEnd("Poop");

		System.out.println(friendsList.getFirst());
		System.out.println(friendsList.getLast());

		assertTrue(friendsList.getLast().equals("Poop"));

	}

	@Test
	public void retrieveFirstMoreThanTwoElementTest() {
		listClasses.BasicLinkedList<String> friendsList = new listClasses.BasicLinkedList();

		friendsList.addToEnd("Apple").addToEnd("Green").addToEnd("Poop");

		System.out.println(friendsList.retrieveFirstElement());

		assertTrue(friendsList.getFirst().equals("Green"));

	}

	@Test
	public void retrieveFirstTwoElementTest() {
		listClasses.BasicLinkedList<String> friendsList = new listClasses.BasicLinkedList();

		friendsList.addToEnd("Apple").addToEnd("Green");

		System.out.println(friendsList.retrieveFirstElement());

		assertTrue(friendsList.getFirst().equals("Green"));

	}

	@Test
	public void retrieveFirstOneElementTest() {
		listClasses.BasicLinkedList<String> friendsList = new listClasses.BasicLinkedList();

		friendsList.addToEnd("Apple");

		System.out.println(friendsList.retrieveFirstElement());

		assertTrue(friendsList.getSize() == 0);

	}

	@Test
	public void retrieveLastMoreThanTwoElementTest() {
		listClasses.BasicLinkedList<String> friendsList = new listClasses.BasicLinkedList();

		friendsList.addToEnd("Apple").addToEnd("Green").addToEnd("Poop");

		System.out.println(friendsList.retrieveLastElement());

		assertTrue(friendsList.getLast().equals("Green"));

	}

	@Test
	public void retrieveLastTwoElementTest() {
		listClasses.BasicLinkedList<String> friendsList = new listClasses.BasicLinkedList();

		friendsList.addToEnd("Apple").addToEnd("Green");

		System.out.println(friendsList.retrieveLastElement());

		assertTrue(friendsList.getLast().equals("Apple"));

	}

	@Test
	public void retrieveLastOneElementTest() {
		listClasses.BasicLinkedList<String> friendsList = new listClasses.BasicLinkedList();

		friendsList.addToEnd("Apple");

		System.out.println(friendsList.retrieveLastElement());

		assertTrue(friendsList.getSize() == 0);

	}

	@Test
	public void BasicRemoveTest() {
		listClasses.BasicLinkedList<String> friendsList = new listClasses.BasicLinkedList();

		friendsList.addToEnd("Apple").addToEnd("Green").addToEnd("Poop").addToEnd("Apple").addToEnd("Poop")
				.addToEnd("Apple");

		System.out.println(friendsList.remove("Apple", new Comparator<String>() {
			public int compare(String o1, String o2) {
				return o1.compareTo(o2);
			}
		}));

		assertTrue(friendsList.getSize() == 3);

	}

	@Test
	public void BasicRemoveOneElementRemovedTest() {
		listClasses.BasicLinkedList<String> friendsList = new listClasses.BasicLinkedList();

		friendsList.addToEnd("Apple");

		System.out.println(friendsList.remove("Apple", new Comparator<String>() {
			public int compare(String o1, String o2) {
				return o1.compareTo(o2);
			}
		}));

		assertTrue(friendsList.getSize() == 0);

	}

	@Test
	public void BasicRemoveTwoElementRemovedTest() {
		listClasses.BasicLinkedList<String> friendsList = new listClasses.BasicLinkedList();

		friendsList.addToEnd("Apple").addToEnd("Apple");

		System.out.println(friendsList.remove("Apple", new Comparator<String>() {
			public int compare(String o1, String o2) {
				return o1.compareTo(o2);
			}
		}));

		friendsList.addToEnd("Apple").addToEnd("Green");

		System.out.println(friendsList.remove("Apple", new Comparator<String>() {
			public int compare(String o1, String o2) {
				return o1.compareTo(o2);
			}
		}));

		friendsList.addToFront("Apple");

		System.out.println(friendsList.remove("Green", new Comparator<String>() {
			public int compare(String o1, String o2) {
				return o1.compareTo(o2);
			}
		}));

		friendsList.addToFront("Apple");

		System.out.println(friendsList.remove("Green", new Comparator<String>() {
			public int compare(String o1, String o2) {
				return o1.compareTo(o2);
			}
		}));

		assertTrue(friendsList.getSize() == 2);

	}

	@Test
	public void BasicRemoveThreeElementRemovedSequentiallyTest() {
		listClasses.BasicLinkedList<String> friendsList = new listClasses.BasicLinkedList();

		friendsList.addToEnd("Apple").addToEnd("Apple").addToEnd("Apple").addToEnd("Apple").addToEnd("Apple")
				.addToEnd("Apple");

		System.out.println(friendsList.remove("Apple", new Comparator<String>() {
			public int compare(String o1, String o2) {
				return o1.compareTo(o2);
			}
		}));

		assertTrue(friendsList.getSize() == 0);

	}

	@Test
	public void IteratorTest() {
		listClasses.BasicLinkedList<String> friendsList = new listClasses.BasicLinkedList();

		friendsList.addToEnd("Apple").addToEnd("Green").addToEnd("Poo");
		String output = "";

		for (String entry : friendsList) {
			output += entry + " ";
		}
		System.out.print(output);

		assertEquals(output, "Apple Green Poo ");

	}

	@Test
	public void getReverseArrayListTest() {
		listClasses.BasicLinkedList<String> friendsList = new listClasses.BasicLinkedList();

		friendsList.addToEnd("Apple").addToEnd("Green").addToEnd("Poo");

		ArrayList<String> reverse = friendsList.getReverseArrayList();

		assertTrue(reverse.get(0).equals("Poo"));

	}

	@Test
	public void getReverseArrayListEmptyTest() {
		listClasses.BasicLinkedList<String> friendsList = new listClasses.BasicLinkedList();

		ArrayList<String> reverse = friendsList.getReverseArrayList();

		assertTrue(reverse.size() == 0);

	}

	@Test
	public void getReverseLinkedListTest() {
		listClasses.BasicLinkedList<String> friendsList = new listClasses.BasicLinkedList();

		friendsList.addToEnd("Apple").addToEnd("Green").addToEnd("Poo");

		listClasses.BasicLinkedList<String> reverse = friendsList.getReverseList();

		assertTrue(reverse.getFirst().equals("Poo"));

	}

	@Test
	public void getReverseLinkedListEmptyTest() {
		listClasses.BasicLinkedList<String> friendsList = new listClasses.BasicLinkedList();

		listClasses.BasicLinkedList<String> reverse = friendsList.getReverseList();

		assertTrue(reverse.getSize() == 0);
	}

	@Test
	public void sortedLinkedListAddTest() {
		listClasses.SortedLinkedList<String> friendsList = new listClasses.SortedLinkedList
		(new Comparator<String>() {
			public int compare(String o1, String o2) {
				return o1.compareTo(o2);
			}
		});

		friendsList.add("a");
		friendsList.add("c");
		friendsList.add("b");
		friendsList.add("e");
		friendsList.add("d");
		friendsList.add("f");

		assertTrue(friendsList.getSize() == 6);
	}

	@Test
	public void sortedLinkedListRemoveTest() {
		listClasses.SortedLinkedList<String> friendsList = new listClasses.SortedLinkedList
		(new Comparator<String>() {
			public int compare(String o1, String o2) {
				return o1.compareTo(o2);
			}
		});

		friendsList.add("a");
		friendsList.add("c");
		friendsList.add("b");
		friendsList.add("e");
		friendsList.add("d");
		friendsList.add("f");

		friendsList.remove("b", new Comparator<String>() {
			public int compare(String o1, String o2) {
				return o1.compareTo(o2);
			}
		});
		assertTrue(friendsList.getSize() == 5);
	}

}

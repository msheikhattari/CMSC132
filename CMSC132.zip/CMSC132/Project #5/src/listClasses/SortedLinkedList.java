package listClasses;

import java.util.*;

/**
 * Implements a generic sorted list using a provided Comparator. It extends
 * BasicLinkedList class.
 * 
 * @author Dept of Computer Science, UMCP
 * 
 */

public class SortedLinkedList<T> extends BasicLinkedList<T> {
	private Comparator<T> comparator;

	public SortedLinkedList(Comparator<T> comparator) {
		super();
		this.comparator = comparator;
	}

	public SortedLinkedList<T> add(T element) {
		if (listSize == 0) {
			head = new Node(element);
			tail = head;
			listSize++;
			return this;
		}

		Node curr = head, prev = null;

		while (curr != null) {
			Node newNode = new Node(element);

			if (curr.next == null) {
				tail = newNode;

				if (comparator.compare(element, curr.data) > 0) {
					head.next = newNode;
				} else {
					newNode.next = head;
					head = newNode;
				}
				listSize++;

				return this;
			}

			if (comparator.compare(element, curr.data) >= 0) {

				while (curr.next != null && comparator.compare(element, curr.data) > 0) {
					prev = curr;
					curr = curr.next;
				}

				if (curr.next == null && comparator.compare(element, curr.data) > 0) {
					tail = newNode;
					curr.next = newNode;
					listSize++;
					return this;
				}

				if (curr == head) {
					if (comparator.compare(element, curr.data) == 0) {
						newNode.next = head;
						head = newNode;
					} else {
						newNode.next = head.next;
						head.next = newNode;
					}
				} else {
					prev.next = newNode;
					newNode.next = curr;
				}
				listSize++;

				return this;
			} else {
				prev = curr;
				curr = curr.next;
			}
		}
		return this;
	}

	public SortedLinkedList<T> remove(T targetData) {
		return (SortedLinkedList<T>) super.remove(targetData, comparator);
	}

	public BasicLinkedList<T> addToEnd(T data) {
		throw new UnsupportedOperationException("Invalid operation for sorted list.");
	}

	public BasicLinkedList<T> addToFront(T data) {
		throw new UnsupportedOperationException("Invalid operation for sorted list.");
	}

}
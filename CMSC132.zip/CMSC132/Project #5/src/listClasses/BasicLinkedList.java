package listClasses;

import java.util.*;

public class BasicLinkedList<T> implements Iterable<T> {

	/* Node definition */
	protected class Node {
		protected T data;
		protected Node next;

		protected Node(T data) {
			this.data = data;
			next = null;
		}
	}

	/* We have both head and tail */
	protected Node head, tail;

	/* size */
	protected int listSize;

	public BasicLinkedList() {
		head = null;
		tail = null;

		listSize = 0;
	}

	public int getSize() {
		return listSize;
	}

	public BasicLinkedList<T> addToEnd(T data) {
		Node newNode = new Node(data);

		if (listSize == 0) {
			head = newNode;
			tail = newNode;
		} else {
			tail.next = newNode;
			tail = newNode;
		}

		listSize++;

		return this;
	}

	public BasicLinkedList<T> addToFront(T data) {
		Node newNode = new Node(data);
		newNode.next = head;
		head = newNode;

		if (listSize == 0) {
			tail = newNode;
		}

		listSize++;

		return this;
	}

	public T getFirst() {
		if (listSize == 0) {
			return null;
		} else {
			return head.data;
		}
	}

	public T getLast() {
		if (listSize == 0) {
			return null;
		} else {
			return tail.data;
		}
	}

	public T retrieveFirstElement() {
		if (listSize == 0) {
			return null;
		} else {
			T returned = head.data;

			if (listSize == 1) {
				head = null;
				tail = null;
			} else {
				head = head.next;
			}

			listSize--;

			return returned;
		}
	}

	public T retrieveLastElement() {
		Node curr = head, prev = null;
		T data = tail.data;
		;

		if (listSize == 0) {
			return null;
		} else if (listSize == 1) {
			head = null;
			tail = null;
			listSize--;

			return data;
		}

		while (curr != null) {
			if (curr.next == null) {
				data = curr.data;
				prev.next = null;
				tail = prev;
				listSize--;
			}
			prev = curr;
			curr = curr.next;
		}
		return data;
	}

	public BasicLinkedList<T> remove(T targetData, Comparator<T> comparator) {
		Node curr = head, prev = null;

		while (curr != null) {
			if (comparator.compare(targetData, curr.data) == 0) {
				if (curr == head) {
					head = head.next;
				} else {
					prev.next = curr.next;

					if (curr == tail) {
						tail = prev;
					}
				}
				listSize--;
			}

			prev = curr;
			curr = curr.next;
		}

		if (listSize == 0) {
			tail = null;
		}

		return this;
	}

	public Iterator<T> iterator() {
		return new Iterator<T>() {
			Node curr = head;

			public boolean hasNext() {
				return (curr != null);

			}

			public T next() {
				if (head == null || curr == null) {
					throw new NoSuchElementException();
				}

				T data = (curr.data);
				curr = curr.next;
				return data;
			}

			public void remove() {
				throw new UnsupportedOperationException();
			}

		};
	}

	public ArrayList<T> getReverseArrayList() {
		return getReverseArrayListAuxiliary(new ArrayList<T>(), head);
	}

	private ArrayList<T> getReverseArrayListAuxiliary(ArrayList<T> list, Node curr) {
		if (curr == null) {
			return list;
		} else {
			list.add(0, curr.data);

			return getReverseArrayListAuxiliary(list, curr.next);
		}
	}

	public BasicLinkedList<T> getReverseList() {
		if (head == null) {
			return new BasicLinkedList<T>();
		} else {
			return getReverseListAuxiliary(new BasicLinkedList<T>(), head, new Node(head.data));
		}
	}

	public BasicLinkedList<T> getReverseListAuxiliary(BasicLinkedList<T> list, Node curr, Node var) {
		if (list.listSize == 0) {
			list.head = var;
			list.tail = var;
		} else {
			var.next = list.head;
			list.head = var;
		}
		list.listSize++;

		if (curr.next == null) {
			return list;
		} else {
			return getReverseListAuxiliary(list, curr.next, new Node(curr.next.data));
		}
	}

}